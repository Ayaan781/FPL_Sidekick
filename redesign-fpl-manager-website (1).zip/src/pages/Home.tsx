import { useEffect, useMemo, useState } from "react";
import { DATA, availability, fmtDate, fmtPrice, players, playersById, teamsById, POS } from "../lib/data";
import { Button, Card, Container, Eyebrow, FixtureChips, Jersey, SectionHeading, StatusBadge } from "../components/ui";
import OptimalTeamSection from "../components/OptimalTeamSection";
import { cn } from "../utils/cn";

function useCountdown(iso: string) {
  const target = new Date(iso).getTime();
  const [now, setNow] = useState(Date.now());
  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(id);
  }, []);
  const diff = Math.max(0, target - now);
  return {
    passed: diff === 0,
    d: Math.floor(diff / 86400000),
    h: Math.floor((diff % 86400000) / 3600000),
    m: Math.floor((diff % 3600000) / 60000),
    s: Math.floor((diff % 60000) / 1000),
  };
}

const FAQ = [
  {
    q: "Where does the data come from?",
    a: "Player prices, form, fixture difficulty, expected points and availability flags all come from the official Fantasy Premier League data feed. We save a snapshot so the app stays fast, and show the snapshot date throughout.",
  },
  {
    q: "How is my squad score calculated?",
    a: "Your score out of 100 combines five areas: current form (25), fixture run (20), availability (20), value & budget use (15) and captain, bench & club spread (20). Every point is explained in your report so you know exactly what to improve.",
  },
  {
    q: "Are the suggestions guaranteed to score points?",
    a: "No. Football is unpredictable. Suggestions are a clear first read based on form, expected points and fixtures — a helpful starting point, not a promise.",
  },
  {
    q: "Is my squad saved?",
    a: "Yes — automatically, in your own browser. Nothing is sent anywhere unless you choose to copy, download or email your report.",
  },
  {
    q: "What are the squad rules?",
    a: "15 players: 2 goalkeepers, 5 defenders, 5 midfielders and 3 forwards, a £100.0m budget and no more than 3 players from any one club. Eleven players start, in a legal formation.",
  },
];

export default function Home() {
  const cd = useCountdown(DATA.nextDeadline);

  const hot = useMemo(
    () =>
      players
        .filter((p) => p.min >= 180 && availability(p) >= 1)
        .sort((a, b) => b.f - a.f || b.tp - a.tp)
        .slice(0, 4),
    [],
  );
  const risers = useMemo(() => [...players].sort((a, b) => b.ti - a.ti).slice(0, 5), []);
  const injuryWatch = useMemo(
    () =>
      players
        .filter((p) => availability(p) < 1 && p.sel > 4)
        .sort((a, b) => b.sel - a.sel)
        .slice(0, 5),
    [],
  );
  const gws = DATA.gws;
  const maxHigh = Math.max(...gws.map((g) => g.high), 1);
  const last = gws[gws.length - 1];
  const topLast = last ? playersById[last.top] : undefined;
  const [open, setOpen] = useState<number | null>(0);

  return (
    <div>
      {/* HERO */}
      <section className="relative overflow-hidden bg-ink-950 text-white">
        <div className="grid-bg pointer-events-none absolute inset-0" />
        <div className="pointer-events-none absolute -right-40 -top-40 h-[34rem] w-[34rem] rounded-full bg-emerald-500/20 blur-3xl" />
        <div className="pointer-events-none absolute -bottom-40 -left-40 h-[28rem] w-[28rem] rounded-full bg-sky-500/10 blur-3xl" />
        <Container className="relative grid items-center gap-12 py-16 sm:py-24 lg:grid-cols-[1.15fr_1fr]">
          <div className="fade-up">
            <Eyebrow dark>Your FPL decision desk</Eyebrow>
            <h1 className="mt-5 font-display text-5xl font-extrabold leading-[1.05] sm:text-6xl lg:text-7xl">
              Better picks.
              <br />
              <span className="bg-gradient-to-r from-emerald-300 to-emerald-500 bg-clip-text text-transparent">Calmer</span> gameweeks.
            </h1>
            <p className="mt-6 max-w-xl text-lg leading-relaxed text-ink-200">
              Build a complete 15-player squad, see the official numbers behind your picks, and get a clear first read on what could be improved — with a score out of 100.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <a href="#/builder">
                <Button className="px-6 py-3.5 text-base">Open the team builder →</Button>
              </a>
              <a href="#/insights">
                <Button variant="outline" className="border-white/20 bg-white/5 px-6 py-3.5 text-base text-white hover:bg-white/10 hover:text-white">
                  Explore player data
                </Button>
              </a>
            </div>
            <p className="mt-8 flex flex-wrap items-center gap-x-3 gap-y-1 text-sm text-ink-300">
              <span className="h-2 w-2 rounded-full bg-emerald-400 pulse-ring" />
              Official player prices and fixture difficulty <span className="text-ink-500">·</span> Updated{" "}
              <time dateTime={DATA.generated}>{fmtDate(DATA.generated)}</time>
            </p>
          </div>

          {/* Deadline card */}
          <div className="fade-up [animation-delay:150ms]">
            <div className="rounded-3xl border border-white/10 bg-white/[0.06] p-6 shadow-2xl backdrop-blur">
              <div className="flex items-center justify-between">
                <p className="text-xs font-bold uppercase tracking-widest text-emerald-300">Gameweek {DATA.nextGw} deadline</p>
                <span className="rounded-full bg-emerald-400/15 px-2.5 py-1 text-[11px] font-bold text-emerald-300">
                  {fmtDate(DATA.nextDeadline, { weekday: "short", day: "numeric", month: "short" })}
                </span>
              </div>
              {cd.passed ? (
                <p className="mt-5 text-lg font-semibold text-white">This deadline has passed — data shown is from our latest snapshot.</p>
              ) : (
                <div className="mt-5 grid grid-cols-4 gap-2 text-center">
                  {[
                    ["Days", cd.d],
                    ["Hours", cd.h],
                    ["Mins", cd.m],
                    ["Secs", cd.s],
                  ].map(([l, v]) => (
                    <div key={l} className="rounded-xl bg-ink-900/80 py-3 ring-1 ring-white/10">
                      <p className="font-display text-3xl font-extrabold tabular-nums">{String(v).padStart(2, "0")}</p>
                      <p className="text-[10px] font-semibold uppercase tracking-widest text-ink-300">{l}</p>
                    </div>
                  ))}
                </div>
              )}
              <div className="mt-6 border-t border-white/10 pt-5">
                <p className="text-xs font-bold uppercase tracking-widest text-ink-300">In form right now</p>
                <ul className="mt-3 space-y-2.5">
                  {hot.slice(0, 3).map((p, i) => (
                    <li key={p.id} className="flex items-center gap-3">
                      <span className="w-4 text-sm font-bold text-ink-400">{i + 1}</span>
                      <Jersey player={p} size={32} />
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-semibold">{p.n}</p>
                        <p className="text-xs text-ink-300">
                          {teamsById[p.t].s} · {POS[p.p].short} · {fmtPrice(p.c)}
                        </p>
                      </div>
                      <span className="rounded-lg bg-emerald-400/15 px-2 py-1 text-sm font-bold text-emerald-300">{p.f.toFixed(1)}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </Container>

        {/* Stats strip */}
        <div className="relative border-t border-white/10 bg-ink-900/60">
          <Container className="grid grid-cols-2 gap-y-6 py-8 md:grid-cols-4">
            {[
              { v: (DATA.totalPlayers / 1e6).toFixed(1) + "m", l: "FPL managers worldwide" },
              { v: String(players.length), l: "Players tracked with live data" },
              { v: last ? String(last.avg) : "–", l: `Average score, GW${last?.id ?? ""}` },
              { v: last ? String(last.high) : "–", l: `Highest score, GW${last?.id ?? ""}` },
            ].map((s) => (
              <div key={s.l} className="px-2 text-center">
                <p className="font-display text-3xl font-extrabold text-white sm:text-4xl">{s.v}</p>
                <p className="mt-1 text-sm text-ink-300">{s.l}</p>
              </div>
            ))}
          </Container>
        </div>
      </section>

      {/* HOW WE HELP */}
      <section id="how-we-help" className="py-20 sm:py-28">
        <Container>
          <div className="grid gap-12 lg:grid-cols-[1fr_1.4fr] lg:items-start">
            <div className="lg:sticky lg:top-28">
              <SectionHeading
                eyebrow="A little clarity goes a long way"
                title={
                  <>
                    Good FPL advice starts with <span className="text-emerald-600">good context.</span>
                  </>
                }
                sub="We're here to help you make the numbers useful. Put in your full squad and get a clearer read on the choices that matter."
              />
              <div className="mt-6 flex flex-wrap gap-x-5 gap-y-2">
                <a href="#/guide" className="inline-flex items-center gap-1 text-sm font-bold text-emerald-700 hover:text-emerald-600">
                  Read the FPL guide →
                </a>
                <a href="#optimal-xi" className="inline-flex items-center gap-1 text-sm font-bold text-ink-900 hover:text-emerald-700">
                  See this week&apos;s optimum XI →
                </a>
              </div>
            </div>
            <div className="grid gap-4 sm:grid-cols-1">
              {[
                {
                  n: "01",
                  t: "Build a balanced squad",
                  d: "Pick a legal formation and let the bench adapt to the official 15-player position totals. Budget and club limits are checked for you with clear explanations.",
                  icon: "M4 6h16M4 12h16M4 18h10",
                },
                {
                  n: "02",
                  t: "Spot useful value",
                  d: "Compare current points, form, price and points-per-million across every position, then filter by club, fitness and affordability.",
                  icon: "M12 3v18M7 8l5-5 5 5M7 16l5 5 5-5",
                },
                {
                  n: "03",
                  t: "Know what to watch",
                  d: "Check next-round estimates, fixture difficulty and availability flags before the deadline so injuries and blanks never catch you out.",
                  icon: "M12 8v4l3 2M21 12a9 9 0 11-18 0 9 9 0 0118 0z",
                },
              ].map((c) => (
                <Card key={c.n} className="group flex gap-5 p-6 transition hover:-translate-y-0.5 hover:border-emerald-300 hover:shadow-lg">
                  <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-ink-900 text-emerald-400 transition group-hover:bg-emerald-500 group-hover:text-ink-950">
                    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d={c.icon} />
                    </svg>
                  </div>
                  <div>
                    <p className="text-xs font-bold tracking-widest text-emerald-700">{c.n}</p>
                    <h3 className="mt-1 text-xl font-bold text-ink-900">{c.t}</h3>
                    <p className="mt-2 leading-relaxed text-slate-600">{c.d}</p>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        </Container>
      </section>

      <OptimalTeamSection />

      {/* PLAYERS TO WATCH */}
      <section className="border-y border-slate-200 bg-white py-20">
        <Container>
          <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
            <SectionHeading eyebrow="This week's talking points" title="Players to watch" sub="The in-form, in-demand and in-doubt names shaping the next deadline." />
            <a href="#/insights" className="text-sm font-bold text-emerald-700 hover:text-emerald-600">
              See all player data →
            </a>
          </div>

          <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {hot.map((p, i) => (
              <Card key={p.id} className="relative overflow-hidden p-5 transition hover:-translate-y-1 hover:shadow-xl">
                <span className="absolute right-4 top-4 rounded-full bg-emerald-50 px-2 py-0.5 text-[11px] font-bold text-emerald-700 ring-1 ring-emerald-200">
                  #{i + 1} form
                </span>
                <Jersey player={p} size={56} />
                <h3 className="mt-3 text-lg font-bold text-ink-900">{p.n}</h3>
                <p className="text-sm text-slate-500">
                  {teamsById[p.t].name} · {POS[p.p].short}
                </p>
                <div className="mt-4 grid grid-cols-3 gap-2 text-center">
                  {[
                    ["Form", p.f.toFixed(1)],
                    ["Pts", p.tp],
                    ["Price", fmtPrice(p.c)],
                  ].map(([l, v]) => (
                    <div key={l} className="rounded-lg bg-slate-50 py-2">
                      <p className="text-sm font-extrabold text-ink-900">{v}</p>
                      <p className="text-[10px] font-semibold uppercase text-slate-500">{l}</p>
                    </div>
                  ))}
                </div>
                <div className="mt-4">
                  <FixtureChips teamId={p.t} n={3} />
                </div>
              </Card>
            ))}
          </div>

          <div className="mt-6 grid gap-6 lg:grid-cols-2">
            <Card className="p-6">
              <h3 className="font-display text-lg font-bold text-ink-900">🔥 Most transferred in this week</h3>
              <ul className="mt-4 divide-y divide-slate-100">
                {risers.map((p) => (
                  <li key={p.id} className="flex items-center gap-3 py-3">
                    <Jersey player={p} size={30} />
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-semibold text-ink-900">{p.n}</p>
                      <p className="text-xs text-slate-500">
                        {teamsById[p.t].s} · {POS[p.p].short} · {fmtPrice(p.c)}
                      </p>
                    </div>
                    <span className="text-sm font-bold text-emerald-700">+{(p.ti / 1000).toFixed(0)}k</span>
                  </li>
                ))}
              </ul>
            </Card>
            <Card className="p-6">
              <h3 className="font-display text-lg font-bold text-ink-900">🩹 Injury &amp; availability watch</h3>
              <p className="text-xs text-slate-500">Popular players carrying a flag.</p>
              <ul className="mt-3 divide-y divide-slate-100">
                {injuryWatch.map((p) => (
                  <li key={p.id} className="flex items-center gap-3 py-3">
                    <Jersey player={p} size={30} />
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-semibold text-ink-900">
                        {p.n} <span className="font-normal text-slate-400">· {p.sel.toFixed(0)}% owned</span>
                      </p>
                      <p className="truncate text-xs text-slate-500">{p.news || "Flagged by FPL"}</p>
                    </div>
                    <StatusBadge player={p} />
                  </li>
                ))}
              </ul>
            </Card>
          </div>
        </Container>
      </section>

      {/* SCORE EXPLAINER */}
      <section className="py-20 sm:py-28">
        <Container>
          <SectionHeading
            center
            eyebrow="Your squad, scored"
            title="A score out of 100 you can actually act on"
            sub="Every squad is graded across five areas, with plain-English feedback and ready-to-use swap suggestions."
          />
          <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
            {[
              { l: "Form", m: 25, d: "How your starters are performing versus others in their position." },
              { l: "Fixtures", m: 20, d: "Average difficulty of the next three matches for your XI." },
              { l: "Availability", m: 20, d: "Injuries, suspensions and fitness doubts across the squad." },
              { l: "Value", m: 15, d: "Points per million and how well you've used your budget." },
              { l: "Structure", m: 20, d: "Captain choice, bench quality and spread across clubs." },
            ].map((c, i) => (
              <Card key={c.l} className="p-5">
                <div className="flex items-baseline justify-between">
                  <span className="text-xs font-bold text-slate-400">0{i + 1}</span>
                  <span className="font-display text-3xl font-extrabold text-emerald-600">{c.m}</span>
                </div>
                <h3 className="mt-2 text-lg font-bold text-ink-900">{c.l}</h3>
                <p className="mt-1.5 text-sm leading-relaxed text-slate-600">{c.d}</p>
              </Card>
            ))}
          </div>

          {/* GW chart */}
          <Card className="mt-12 p-6 sm:p-8">
            <div className="flex flex-col justify-between gap-2 sm:flex-row sm:items-end">
              <div>
                <h3 className="font-display text-xl font-bold text-ink-900">How the season is going</h3>
                <p className="text-sm text-slate-500">Average and highest manager score each gameweek.</p>
              </div>
              {topLast && (
                <p className="text-sm text-slate-600">
                  GW{last.id} star: <b className="text-ink-900">{topLast.n}</b> with {last.topPts} pts
                </p>
              )}
            </div>
            <div className="mt-8 flex h-56 items-end gap-3 sm:gap-6">
              {gws.map((g) => (
                <div key={g.id} className="group flex h-full flex-1 flex-col items-center justify-end gap-2">
                  <div className="flex h-full w-full items-end justify-center gap-1.5">
                    <div
                      className="relative w-full max-w-[34px] rounded-t-md bg-ink-800 transition-all group-hover:bg-ink-700"
                      style={{ height: `${(g.avg / maxHigh) * 100}%` }}
                      title={`Average ${g.avg}`}
                    >
                      <span className="absolute -top-5 left-1/2 -translate-x-1/2 text-[11px] font-bold text-ink-900">{g.avg}</span>
                    </div>
                    <div
                      className="relative w-full max-w-[34px] rounded-t-md bg-emerald-500 transition-all group-hover:bg-emerald-400"
                      style={{ height: `${(g.high / maxHigh) * 100}%` }}
                      title={`Highest ${g.high}`}
                    >
                      <span className="absolute -top-5 left-1/2 -translate-x-1/2 text-[11px] font-bold text-emerald-700">{g.high}</span>
                    </div>
                  </div>
                  <span className="text-xs font-semibold text-slate-500">GW{g.id}</span>
                </div>
              ))}
            </div>
            <div className="mt-5 flex gap-5 text-xs font-medium text-slate-600">
              <span className="flex items-center gap-2">
                <i className="h-3 w-3 rounded bg-ink-800" /> Average
              </span>
              <span className="flex items-center gap-2">
                <i className="h-3 w-3 rounded bg-emerald-500" /> Highest
              </span>
            </div>
          </Card>
        </Container>
      </section>

      {/* FAQ */}
      <section className="border-t border-slate-200 bg-white py-20">
        <Container className="max-w-3xl">
          <SectionHeading center eyebrow="Questions, answered" title="Frequently asked" />
          <div className="mt-10 divide-y divide-slate-200 rounded-2xl border border-slate-200">
            {FAQ.map((f, i) => (
              <div key={f.q}>
                <button
                  className="flex w-full items-center justify-between gap-4 px-5 py-4 text-left"
                  aria-expanded={open === i}
                  onClick={() => setOpen(open === i ? null : i)}
                >
                  <span className="font-semibold text-ink-900">{f.q}</span>
                  <span className={cn("flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-slate-100 text-lg text-ink-700 transition", open === i && "rotate-45 bg-emerald-500 text-ink-950")}>
                    +
                  </span>
                </button>
                {open === i && <p className="pop px-5 pb-5 leading-relaxed text-slate-600">{f.a}</p>}
              </div>
            ))}
          </div>
        </Container>
      </section>

      {/* CTA */}
      <section className="py-20">
        <Container>
          <div className="relative overflow-hidden rounded-3xl bg-ink-900 px-8 py-14 text-center text-white sm:px-16">
            <div className="grid-bg pointer-events-none absolute inset-0" />
            <div className="pointer-events-none absolute -top-24 left-1/2 h-64 w-64 -translate-x-1/2 rounded-full bg-emerald-500/30 blur-3xl" />
            <div className="relative">
              <Eyebrow dark>Your next move starts here</Eyebrow>
              <h2 className="mt-3 font-display text-3xl font-extrabold sm:text-5xl">Ready to build your squad?</h2>
              <p className="mx-auto mt-4 max-w-xl text-ink-200">It takes about two minutes — or let Sidekick auto-pick a balanced team and refine from there.</p>
              <a href="#/builder" className="mt-8 inline-block">
                <Button className="px-8 py-4 text-base">Open the team builder →</Button>
              </a>
            </div>
          </div>
        </Container>
      </section>
    </div>
  );
}
