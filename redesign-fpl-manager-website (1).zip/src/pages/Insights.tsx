import { useEffect, useMemo, useState } from "react";
import { POS, availability, fmtPrice, players, rating, teams, teamsById, type Player, type Pos } from "../lib/data";
import { Card, Container, Eyebrow, FixtureChips, Jersey, StatusBadge } from "../components/ui";
import { cn } from "../utils/cn";

type Preset = "all" | "form" | "value" | "diff" | "owned" | "risers" | "flagged";
const PRESETS: { key: Preset; label: string; hint: string }[] = [
  { key: "all", label: "All players", hint: "Every player, sorted by Sidekick rating." },
  { key: "form", label: "Top form", hint: "Highest recent form among players who've been playing regularly." },
  { key: "value", label: "Best value", hint: "Most points per £m for players with real minutes." },
  { key: "diff", label: "Differentials", hint: "In-form players owned by fewer than 10% of managers." },
  { key: "owned", label: "Most owned", hint: "The template — who the crowd trusts most." },
  { key: "risers", label: "Price risers", hint: "Players whose price has gone up since the season began." },
  { key: "flagged", label: "Flagged", hint: "Players with an injury, suspension or fitness flag, most-owned first." },
];

type Col = "n" | "c" | "f" | "tp" | "ep" | "sel" | "vs" | "ti";
const num = (p: Player, c: Col): number | string => (c === "n" ? p.n : c === "vs" ? p.tp / (p.c / 10) : (p[c] as number));

export default function Insights() {
  const [preset, setPreset] = useState<Preset>("all");
  const [pos, setPos] = useState<0 | Pos>(0);
  const [team, setTeam] = useState(0);
  const [q, setQ] = useState("");
  const [sort, setSort] = useState<{ col: Col | "rating"; dir: 1 | -1 } | null>(null);
  const [limit, setLimit] = useState(30);

  useEffect(() => setLimit(30), [preset, pos, team, q, sort]);

  const rows = useMemo(() => {
    const nq = q.trim().toLowerCase();
    let r = players.filter((p) => (!pos || p.p === pos) && (!team || p.t === team) && (!nq || `${p.n} ${p.fn} ${p.sn} ${teamsById[p.t].name}`.toLowerCase().includes(nq)));
    let base: (a: Player, b: Player) => number = (a, b) => rating(b) - rating(a);
    switch (preset) {
      case "form":
        r = r.filter((p) => p.min >= 180);
        base = (a, b) => b.f - a.f || b.tp - a.tp;
        break;
      case "value":
        r = r.filter((p) => p.min >= 180);
        base = (a, b) => b.tp / b.c - a.tp / a.c;
        break;
      case "diff":
        r = r.filter((p) => p.sel < 10 && p.min >= 180 && p.f >= 4);
        base = (a, b) => b.f - a.f;
        break;
      case "owned":
        base = (a, b) => b.sel - a.sel;
        break;
      case "risers":
        r = r.filter((p) => p.cc > 0);
        base = (a, b) => b.cc - a.cc || b.sel - a.sel;
        break;
      case "flagged":
        r = r.filter((p) => availability(p) < 1);
        base = (a, b) => b.sel - a.sel;
        break;
    }
    if (sort) {
      const { col, dir } = sort;
      r = [...r].sort((a, b) => {
        if (col === "rating") return (rating(a) - rating(b)) * dir;
        const x = num(a, col);
        const y = num(b, col);
        return typeof x === "string" ? x.localeCompare(y as string) * dir : ((x as number) - (y as number)) * dir;
      });
    } else r = [...r].sort(base);
    return r;
  }, [preset, pos, team, q, sort]);

  const headSort = (col: Col) => setSort((s) => (s?.col === col ? { col, dir: (s.dir * -1) as 1 | -1 } : { col, dir: col === "n" ? 1 : -1 }));
  const Th = ({ col, label, className }: { col: Col; label: string; className?: string }) => (
    <th className={cn("px-3 py-3 font-semibold", className)} aria-sort={sort?.col === col ? (sort.dir === 1 ? "ascending" : "descending") : "none"}>
      <button onClick={() => headSort(col)} className="inline-flex items-center gap-1 uppercase tracking-wide hover:text-ink-900">
        {label}
        <span className={cn("text-[10px]", sort?.col === col ? "text-emerald-600" : "text-slate-300")}>{sort?.col === col && sort.dir === 1 ? "▲" : "▼"}</span>
      </button>
    </th>
  );

  const top3 = [...players].filter((p) => p.min >= 180).sort((a, b) => b.tp - a.tp).slice(0, 3);
  const hint = PRESETS.find((p) => p.key === preset)!.hint;

  return (
    <div>
      <section className="relative overflow-hidden bg-ink-900 text-white">
        <div className="grid-bg pointer-events-none absolute inset-0" />
        <Container className="relative py-14 sm:py-20">
          <Eyebrow dark>The numbers behind your picks</Eyebrow>
          <h1 className="mt-3 max-w-3xl font-display text-4xl font-extrabold leading-tight sm:text-5xl">
            Player <span className="text-emerald-400">insights.</span>
          </h1>
          <p className="mt-4 max-w-2xl text-ink-200">
            Search and sort every Premier League player by form, value, ownership and fitness. Click a column to re-sort. Official FPL data, saved as a snapshot.
          </p>
          <div className="mt-8 grid gap-3 sm:grid-cols-3">
            {top3.map((p, i) => (
              <div key={p.id} className="flex items-center gap-3 rounded-2xl border border-white/10 bg-white/5 p-4">
                <span className="font-display text-2xl font-extrabold text-emerald-400">{i + 1}</span>
                <Jersey player={p} size={40} />
                <div className="min-w-0 flex-1">
                  <p className="truncate font-semibold">{p.n}</p>
                  <p className="text-xs text-ink-300">
                    {teamsById[p.t].name} · {fmtPrice(p.c)}
                  </p>
                </div>
                <div className="text-right">
                  <p className="font-display text-xl font-extrabold">{p.tp}</p>
                  <p className="text-[10px] uppercase tracking-wider text-ink-300">points</p>
                </div>
              </div>
            ))}
          </div>
        </Container>
      </section>

      <Container className="py-10">
        <div className="flex flex-wrap gap-2" role="tablist" aria-label="Player views">
          {PRESETS.map((p) => (
            <button
              key={p.key}
              role="tab"
              aria-selected={preset === p.key}
              onClick={() => {
                setPreset(p.key);
                setSort(null);
              }}
              className={cn(
                "rounded-full px-4 py-2 text-sm font-semibold transition",
                preset === p.key ? "bg-ink-900 text-white shadow" : "bg-white text-slate-600 ring-1 ring-slate-200 hover:ring-emerald-400",
              )}
            >
              {p.label}
            </button>
          ))}
        </div>
        <p className="mt-3 text-sm text-slate-600">{hint}</p>

        <Card className="mt-5 overflow-hidden">
          <div className="flex flex-col gap-3 border-b border-slate-100 p-4 lg:flex-row lg:items-center">
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Search players or clubs…"
              aria-label="Search players"
              className="w-full flex-1 rounded-xl border border-slate-200 bg-slate-50 px-4 py-2.5 text-sm focus:border-emerald-500 focus:bg-white focus:outline-none"
            />
            <div className="flex flex-wrap gap-1.5">
              {([0, 1, 2, 3, 4] as const).map((p) => (
                <button
                  key={p}
                  onClick={() => setPos(p)}
                  className={cn("rounded-lg px-3 py-2 text-xs font-bold", pos === p ? "bg-emerald-500 text-ink-950" : "bg-slate-100 text-slate-600 hover:bg-slate-200")}
                >
                  {p === 0 ? "ALL" : POS[p].short}
                </button>
              ))}
            </div>
            <select
              value={team}
              onChange={(e) => setTeam(Number(e.target.value))}
              aria-label="Filter by club"
              className="rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm"
            >
              <option value={0}>All clubs</option>
              {teams.map((t) => (
                <option key={t.id} value={t.id}>
                  {t.name}
                </option>
              ))}
            </select>
          </div>

          <div className="scroll-thin overflow-x-auto">
            <table className="w-full min-w-[860px] text-left text-sm">
              <thead className="bg-slate-50 text-xs text-slate-500">
                <tr>
                  <th className="w-10 px-3 py-3">#</th>
                  <Th col="n" label="Player" />
                  <Th col="c" label="Price" />
                  <Th col="f" label="Form" />
                  <Th col="tp" label="Pts" />
                  <Th col="ep" label="xPts" />
                  <Th col="vs" label="Pts/£m" />
                  <Th col="sel" label="Sel %" />
                  <th className="px-3 py-3 font-semibold uppercase tracking-wide">Next 3</th>
                  <th className="px-3 py-3 font-semibold uppercase tracking-wide">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {rows.slice(0, limit).map((p, i) => (
                  <tr key={p.id} className="transition hover:bg-emerald-50/50">
                    <td className="px-3 py-3 text-slate-400">{i + 1}</td>
                    <td className="px-3 py-3">
                      <div className="flex items-center gap-3">
                        <Jersey player={p} size={32} />
                        <div>
                          <p className="font-semibold text-ink-900">{p.n}</p>
                          <p className="text-xs text-slate-500">
                            {teamsById[p.t].name} · {POS[p.p].short}
                          </p>
                        </div>
                      </div>
                    </td>
                    <td className="px-3 py-3 font-semibold">{fmtPrice(p.c)}</td>
                    <td className="px-3 py-3">
                      <span className={cn("rounded-md px-2 py-0.5 font-bold", p.f >= 6 ? "bg-emerald-100 text-emerald-800" : p.f >= 3.5 ? "bg-slate-100 text-slate-700" : "bg-rose-50 text-rose-700")}>
                        {p.f.toFixed(1)}
                      </span>
                    </td>
                    <td className="px-3 py-3 font-semibold">{p.tp}</td>
                    <td className="px-3 py-3">{p.ep.toFixed(1)}</td>
                    <td className="px-3 py-3">{(p.tp / (p.c / 10)).toFixed(1)}</td>
                    <td className="px-3 py-3">{p.sel.toFixed(1)}%</td>
                    <td className="px-3 py-3">
                      <FixtureChips teamId={p.t} n={3} />
                    </td>
                    <td className="px-3 py-3">
                      <StatusBadge player={p} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {rows.length === 0 && (
              <div className="py-16 text-center">
                <p className="font-display text-lg font-bold text-ink-900">Nothing matches those filters</p>
                <p className="mt-1 text-sm text-slate-500">Try another view, position or club.</p>
              </div>
            )}
          </div>
          <div className="flex items-center justify-between border-t border-slate-100 bg-slate-50 px-4 py-3 text-sm text-slate-600">
            <span>
              Showing {Math.min(limit, rows.length)} of {rows.length} players
            </span>
            {rows.length > limit && (
              <button onClick={() => setLimit((l) => l + 30)} className="rounded-lg bg-ink-900 px-4 py-2 text-sm font-semibold text-white hover:bg-ink-800">
                Show more
              </button>
            )}
          </div>
        </Card>
        <p className="mt-4 text-xs text-slate-500">
          xPts = official expected points for the next gameweek. Form = average points over the last 30 days. Figures can change and are not guaranteed.
        </p>
      </Container>
    </div>
  );
}
