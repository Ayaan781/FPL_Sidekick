import { useMemo, useRef, useState } from "react";
import { BUDGET, MAX_PER_CLUB, POS, availability, avgFdr, fixturesOf, fmtPrice, playersById, statusLabel, teamsById, type Player } from "../lib/data";
import {
  FORMATIONS,
  buildReview,
  buildSlots,
  clubCounts,
  isComplete,
  spent,
  squadPlayers,
  type Slot,
} from "../lib/squad";
import { useSquad, useToast } from "../lib/hooks";
import { cn } from "../utils/cn";
import { PlayerPicker } from "../components/PlayerPicker";
import { ReviewPanel } from "../components/ReviewPanel";
import { Button, Card, Container, Eyebrow, Jersey } from "../components/ui";
import { DATA, fmtDate } from "../lib/data";

/* ---------------- Slot card ---------------- */
function SlotCard({
  slot,
  player,
  isC,
  isV,
  onOpen,
  onRemove,
  onCaptain,
  onVice,
  dark,
}: {
  slot: Slot;
  player?: Player;
  isC: boolean;
  isV: boolean;
  onOpen: () => void;
  onRemove: () => void;
  onCaptain: () => void;
  onVice: () => void;
  dark?: boolean;
}) {
  if (!player) {
    return (
      <button
        onClick={onOpen}
        aria-label={`Add a ${POS[slot.pos].name}`}
        className="group flex w-[60px] flex-col items-center gap-1.5 sm:w-[108px]"
      >
        <span
          className={cn(
            "flex h-11 w-11 items-center justify-center rounded-full border-2 border-dashed text-2xl font-light transition group-hover:scale-110 sm:h-14 sm:w-14",
            dark
              ? "border-emerald-300/70 bg-white/10 text-emerald-100 group-hover:bg-white/20"
              : "border-slate-300 bg-white text-slate-400 group-hover:border-emerald-500 group-hover:text-emerald-600",
          )}
        >
          +
        </span>
        <span className={cn("rounded-md px-2 py-0.5 text-[11px] font-bold", dark ? "bg-black/25 text-white" : "bg-slate-100 text-slate-600")}>
          {POS[slot.pos].short}
        </span>
      </button>
    );
  }
  const st = statusLabel(player);
  const next = fixturesOf(player.t, 1)[0];
  return (
    <div className="pop relative flex w-[60px] flex-col items-center sm:w-[108px]">
      <button onClick={onOpen} className="flex w-full flex-col items-center" aria-label={`${player.n}, swap player`}>
        <div className="relative">
          <Jersey player={player} size={44} />
          {st.tone !== "ok" && (
            <span
              title={player.news || st.text}
              className={cn(
                "absolute -right-2 -top-1 flex h-5 w-5 items-center justify-center rounded-full border-2 border-white text-[10px] font-extrabold text-white",
                st.tone === "bad" ? "bg-rose-500" : "bg-amber-500",
              )}
            >
              !
            </span>
          )}
          {(isC || isV) && (
            <span className="absolute -left-2 -top-1 flex h-5 w-5 items-center justify-center rounded-full border-2 border-white bg-ink-900 text-[10px] font-extrabold text-white">
              {isC ? "C" : "V"}
            </span>
          )}
        </div>
        <span className="mt-1 w-full truncate rounded-t-md bg-white px-1 py-0.5 text-center text-[11px] font-bold text-ink-900 sm:text-xs">{player.n}</span>
        <span className="w-full truncate rounded-b-md bg-ink-900 px-1 py-0.5 text-center text-[10px] font-medium text-white">
          {fmtPrice(player.c)}
          {next && <span className="hidden text-emerald-300 sm:inline"> · {teamsById[next.o].s}</span>}
        </span>
      </button>
      <div className="mt-1 flex items-center gap-0.5 sm:gap-1">
        {!slot.bench && (
          <>
            <button
              onClick={onCaptain}
              title="Make captain"
              aria-label={`Make ${player.n} captain`}
              className={cn("h-[18px] w-[18px] rounded-full text-[10px] font-bold transition sm:h-5 sm:w-5", isC ? "bg-amber-400 text-ink-950" : "bg-white/90 text-ink-700 hover:bg-amber-300")}
            >
              C
            </button>
            <button
              onClick={onVice}
              title="Make vice-captain"
              aria-label={`Make ${player.n} vice-captain`}
              className={cn("h-[18px] w-[18px] rounded-full text-[10px] font-bold transition sm:h-5 sm:w-5", isV ? "bg-amber-400 text-ink-950" : "bg-white/90 text-ink-700 hover:bg-amber-300")}
            >
              V
            </button>
          </>
        )}
        <button
          onClick={onRemove}
          title="Remove player"
          aria-label={`Remove ${player.n}`}
          className="flex h-[18px] w-[18px] items-center justify-center rounded-full bg-white/90 text-rose-600 sm:h-5 sm:w-5 transition hover:bg-rose-500 hover:text-white"
        >
          <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="4" strokeLinecap="round">
            <path d="M6 6l12 12M18 6L6 18" />
          </svg>
        </button>
      </div>
    </div>
  );
}

/* ---------------- Page ---------------- */
export default function Builder() {
  const { state, caps, setFormation, assign, remove, setCaptain, reset, auto } = useSquad();
  const toast = useToast();
  const [active, setActive] = useState<Slot | null>(null);
  const [manager, setManager] = useState(() => localStorage.getItem("fpl-sidekick-manager") ?? "");
  const [showReview, setShowReview] = useState(false);
  const topRef = useRef<HTMLDivElement>(null);

  const { xi, bench } = useMemo(() => buildSlots(state.formation), [state.formation]);
  const list = squadPlayers(state);
  const total = spent(state);
  const remaining = BUDGET - total;
  const clubs = clubCounts(list);
  const maxClub = Math.max(0, ...Object.values(clubs));
  const complete = isComplete(state);
  const review = useMemo(() => (complete && showReview ? buildReview(state) : null), [complete, showReview, state]);

  const get = (s: Slot) => (state.picks[s.id] ? playersById[state.picks[s.id] as number] : undefined);
  const xiRows = ([1, 2, 3, 4] as const).map((pos) => xi.filter((s) => s.pos === pos));
  const xiPlayers = xi.map(get).filter(Boolean) as Player[];

  /* live insights */
  const flagged = list.filter((p) => availability(p) < 1);
  const avgForm = xiPlayers.length ? xiPlayers.reduce((t, p) => t + p.f, 0) / xiPlayers.length : 0;
  const avgFix = xiPlayers.length ? xiPlayers.reduce((t, p) => t + avgFdr(p.t, 3), 0) / xiPlayers.length : 0;
  const avgEp = xiPlayers.length ? xiPlayers.reduce((t, p) => t + p.ep, 0) / xiPlayers.length : 0;
  const posSpend = ([1, 2, 3, 4] as const).map((pos) => ({ pos, v: list.filter((p) => p.p === pos).reduce((t, p) => t + p.c, 0) }));
  const blankTeams = list.filter((p) => fixturesOf(p.t, 1)[0]?.e !== DATA.nextGw);

  const checks = [
    { ok: list.length === 15, label: `15 players picked (${list.length}/15)` },
    { ok: remaining >= 0, label: remaining >= 0 ? `Within budget (${fmtPrice(remaining)} left)` : "Over budget" },
    { ok: maxClub <= MAX_PER_CLUB, label: `Max ${MAX_PER_CLUB} per club` },
    { ok: !!caps.captain, label: caps.captain ? "Captain chosen" : "Choose a captain" },
  ];

  const tips: { tone: "good" | "warn" | "bad"; text: string }[] = [];
  if (list.length === 0) tips.push({ tone: "good", text: "Start by tapping a “+” slot, or let Sidekick auto-pick a balanced squad." });
  flagged.slice(0, 4).forEach((p) => {
    const st = statusLabel(p);
    tips.push({ tone: st.tone === "bad" ? "bad" : "warn", text: `${p.n}: ${p.news || st.text}` });
  });
  if (list.length > 0 && list.length < 15) tips.push({ tone: "warn", text: `${15 - list.length} more player${15 - list.length === 1 ? "" : "s"} needed to unlock your score.` });
  if (complete && remaining > 20) tips.push({ tone: "warn", text: `${fmtPrice(remaining)} unspent — consider upgrading a starter.` });
  if (xiPlayers.length >= 6 && avgFix >= 3.7) tips.push({ tone: "warn", text: "Your starters have a tough run of fixtures." });
  if (xiPlayers.length >= 6 && avgFix <= 2.6) tips.push({ tone: "good", text: "Great fixture run for your starting XI." });
  if (blankTeams.length) tips.push({ tone: "warn", text: `${blankTeams.length} player${blankTeams.length > 1 ? "s have" : " has"} no fixture in GW${DATA.nextGw}.` });
  if (list.length >= 11 && !caps.captain) tips.push({ tone: "warn", text: "Pick a captain with the “C” button under a starter." });
  if (!tips.length) tips.push({ tone: "good", text: "No issues spotted so far. Looking good." });

  const openSlot = (s: Slot) => setActive(s);

  const submit = () => {
    localStorage.setItem("fpl-sidekick-manager", manager);
    if (!complete) {
      toast(`Pick ${15 - list.length} more player${15 - list.length === 1 ? "" : "s"} to get your score.`, "warn");
      return;
    }
    if (remaining < 0) {
      toast("You're over budget — swap in a cheaper player first.", "error");
      return;
    }
    setShowReview(true);
    toast("Your squad review is ready!", "success");
    setTimeout(() => document.getElementById("review")?.scrollIntoView({ behavior: "smooth" }), 80);
  };

  return (
    <div>
      {/* Header */}
      <section className="relative overflow-hidden bg-ink-900 text-white">
        <div className="grid-bg pointer-events-none absolute inset-0" />
        <Container className="relative py-12 sm:py-16">
          <div className="flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
            <div className="max-w-2xl">
              <Eyebrow dark>Make every pick count</Eyebrow>
              <h1 className="mt-3 font-display text-4xl font-extrabold leading-tight sm:text-5xl">
                Build your <span className="text-emerald-400">starting XI.</span>
              </h1>
              <p className="mt-4 text-ink-200">
                Build the full 15-player squad. Your bench adjusts with the formation so the official FPL position totals — 2 GKP · 5 DEF · 5 MID · 3 FWD — always stay valid.
              </p>
            </div>
            <div className="flex w-fit items-center gap-3 rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-sm">
              <span className="h-2.5 w-2.5 rounded-full bg-emerald-400 pulse-ring" />
              <div>
                <p className="text-[11px] font-bold uppercase tracking-widest text-emerald-300">Official FPL player data</p>
                <p className="text-ink-200">Snapshot {fmtDate(DATA.generated, { day: "numeric", month: "short", year: "numeric" })}</p>
              </div>
            </div>
          </div>
        </Container>
      </section>

      <Container className="-mt-6 pb-4">
        <div ref={topRef} />
        {/* Budget summary */}
        <Card className="grid gap-5 p-5 sm:grid-cols-[2fr_1fr_1fr] sm:p-6">
          <div>
            <div className="flex items-baseline justify-between">
              <p className="text-xs font-bold uppercase tracking-widest text-slate-500">Squad spend</p>
              <p className="text-xs text-slate-500">
                {fmtPrice(total)} of {fmtPrice(BUDGET)}
              </p>
            </div>
            <p className={cn("mt-1 font-display text-3xl font-extrabold", remaining < 0 ? "text-rose-600" : "text-ink-900")}>
              {fmtPrice(remaining)} <span className="text-sm font-semibold text-slate-500">{remaining < 0 ? "over budget" : "remaining"}</span>
            </p>
            <div className="mt-3 h-2.5 overflow-hidden rounded-full bg-slate-100">
              <div
                className={cn("h-full rounded-full transition-all duration-500", remaining < 0 ? "bg-rose-500" : "bg-gradient-to-r from-emerald-500 to-emerald-400")}
                style={{ width: `${Math.min(100, (total / BUDGET) * 100)}%` }}
              />
            </div>
          </div>
          <div className="rounded-xl bg-slate-50 p-4">
            <p className="font-display text-3xl font-extrabold text-ink-900">
              {list.length}
              <span className="text-base font-semibold text-slate-400"> / 15</span>
            </p>
            <p className="text-xs font-medium text-slate-500">players picked</p>
          </div>
          <div className={cn("rounded-xl p-4", maxClub > MAX_PER_CLUB ? "bg-rose-50" : "bg-slate-50")}>
            <p className="font-display text-3xl font-extrabold text-ink-900">
              {maxClub}
              <span className="text-base font-semibold text-slate-400"> / {MAX_PER_CLUB} max</span>
            </p>
            <p className="text-xs font-medium text-slate-500">largest club share</p>
          </div>
        </Card>

        <div className="mt-6 grid gap-6 lg:grid-cols-[1fr_340px]">
          <div className="space-y-6">
            {/* Pitch */}
            <Card className="overflow-hidden">
              <div className="flex flex-col gap-4 border-b border-slate-100 p-5 sm:flex-row sm:items-center sm:justify-between">
                <div>
                  <p className="text-xs font-bold uppercase tracking-widest text-emerald-700">Your squad</p>
                  <h2 className="font-display text-2xl font-extrabold text-ink-900">The starting XI</h2>
                </div>
                <div className="flex flex-wrap gap-2">
                  <Button variant="dark" onClick={auto}>
                    ✨ Auto-pick squad
                  </Button>
                  <Button
                    variant="danger"
                    disabled={list.length === 0}
                    onClick={() => {
                      if (window.confirm("Clear your whole squad?")) {
                        reset();
                        setShowReview(false);
                      }
                    }}
                  >
                    Reset
                  </Button>
                </div>
              </div>
              <div className="border-b border-slate-100 bg-slate-50 px-5 py-3">
                <p className="mb-2 text-[11px] font-bold uppercase tracking-widest text-slate-500">Formation</p>
                <div className="flex flex-wrap gap-1.5" role="radiogroup" aria-label="Formation">
                  {FORMATIONS.map((f) => (
                    <button
                      key={f}
                      role="radio"
                      aria-checked={state.formation === f}
                      onClick={() => state.formation !== f && setFormation(f)}
                      className={cn(
                        "rounded-lg px-3 py-1.5 text-sm font-bold transition",
                        state.formation === f ? "bg-ink-900 text-white shadow" : "bg-white text-slate-600 ring-1 ring-slate-200 hover:ring-emerald-400",
                      )}
                    >
                      {f}
                    </button>
                  ))}
                </div>
              </div>

              <div className="pitch relative px-2 py-8 sm:px-6">
                <svg className="pointer-events-none absolute inset-0 h-full w-full" preserveAspectRatio="none" viewBox="0 0 100 100" aria-hidden>
                  <g fill="none" stroke="rgba(255,255,255,0.35)" strokeWidth="1.5" vectorEffect="non-scaling-stroke">
                    <rect x="3" y="3" width="94" height="94" vectorEffect="non-scaling-stroke" />
                    <line x1="3" y1="50" x2="97" y2="50" vectorEffect="non-scaling-stroke" />
                    <circle cx="50" cy="50" r="9" vectorEffect="non-scaling-stroke" />
                    <rect x="28" y="3" width="44" height="14" vectorEffect="non-scaling-stroke" />
                    <rect x="28" y="83" width="44" height="14" vectorEffect="non-scaling-stroke" />
                  </g>
                </svg>
                <div className="relative flex flex-col gap-7 sm:gap-9">
                  {[...xiRows].reverse().map((row, i) => (
                    <div key={i} className="flex justify-center gap-0.5 sm:gap-4">
                      {row.map((s) => (
                        <SlotCard
                          key={s.id}
                          slot={s}
                          dark
                          player={get(s)}
                          isC={get(s)?.id === caps.captain}
                          isV={get(s)?.id === caps.vice}
                          onOpen={() => openSlot(s)}
                          onRemove={() => remove(s.id)}
                          onCaptain={() => get(s) && setCaptain(get(s)!.id, "captain")}
                          onVice={() => get(s) && setCaptain(get(s)!.id, "vice")}
                        />
                      ))}
                    </div>
                  ))}
                </div>
              </div>
              <p className="flex items-center gap-2 bg-slate-50 px-5 py-3 text-sm text-slate-600" role="status">
                <span className="h-2 w-2 rounded-full bg-emerald-500" />
                {list.length === 0
                  ? "Choose a slot, then add a player from the list."
                  : `Tap a player to swap them. Use C / V to set captain and vice-captain.`}
              </p>
            </Card>

            {/* Bench */}
            <Card className="p-5 sm:p-6">
              <div className="flex items-end justify-between">
                <div>
                  <p className="text-xs font-bold uppercase tracking-widest text-emerald-700">The substitutes</p>
                  <h2 className="font-display text-2xl font-extrabold text-ink-900">Your four-player bench</h2>
                </div>
                <span className="hidden rounded-full bg-slate-100 px-3 py-1 text-xs font-semibold text-slate-600 sm:inline">FPL squad balance</span>
              </div>
              <div className="mt-5 grid grid-cols-4 gap-2 rounded-2xl bg-slate-100 p-3 sm:gap-4 sm:p-5">
                {bench.map((s, i) => (
                  <div key={s.id} className="flex flex-col items-center gap-2">
                    <span className="text-[11px] font-bold text-slate-500">{i === 0 ? "GKP" : `${i}. ${POS[s.pos].short}`}</span>
                    <SlotCard
                      slot={s}
                      player={get(s)}
                      isC={false}
                      isV={false}
                      onOpen={() => openSlot(s)}
                      onRemove={() => remove(s.id)}
                      onCaptain={() => {}}
                      onVice={() => {}}
                    />
                  </div>
                ))}
              </div>
              <p className="mt-4 text-sm text-slate-600">
                Bench positions adjust with your formation so the full squad remains 2 GKP · 5 DEF · 5 MID · 3 FWD. Currently:{" "}
                <b className="text-ink-900">{bench.map((b) => POS[b.pos].short).join(" · ")}</b>.
              </p>
            </Card>
          </div>

          {/* Sidebar insights */}
          <aside className="space-y-6 lg:sticky lg:top-24 lg:self-start" id="squad-insights" aria-labelledby="insights-title">
            <Card className="p-5">
              <p className="text-xs font-bold uppercase tracking-widest text-emerald-700">A quick read on your picks</p>
              <h2 id="insights-title" className="font-display text-xl font-extrabold text-ink-900">
                Sidekick insights
              </h2>

              <ul className="mt-4 space-y-2">
                {checks.map((c) => (
                  <li key={c.label} className="flex items-center gap-2.5 text-sm">
                    <span className={cn("flex h-5 w-5 items-center justify-center rounded-full text-xs font-bold", c.ok ? "bg-emerald-100 text-emerald-700" : "bg-slate-100 text-slate-400")}>
                      {c.ok ? "✓" : "•"}
                    </span>
                    <span className={c.ok ? "text-ink-900" : "text-slate-500"}>{c.label}</span>
                  </li>
                ))}
              </ul>

              <div className="mt-5 grid grid-cols-3 gap-2 text-center">
                {[
                  { l: "Avg form", v: xiPlayers.length ? avgForm.toFixed(1) : "–" },
                  { l: "Avg xPts", v: xiPlayers.length ? avgEp.toFixed(1) : "–" },
                  { l: "Fixture ease", v: xiPlayers.length ? (5 - avgFix).toFixed(1) : "–" },
                ].map((m) => (
                  <div key={m.l} className="rounded-xl bg-slate-50 p-2.5">
                    <p className="font-display text-lg font-extrabold text-ink-900">{m.v}</p>
                    <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-500">{m.l}</p>
                  </div>
                ))}
              </div>

              <div className="mt-5">
                <p className="text-[11px] font-bold uppercase tracking-widest text-slate-500">Spend by position</p>
                <div className="mt-2 space-y-1.5">
                  {posSpend.map(({ pos, v }) => (
                    <div key={pos} className="flex items-center gap-2 text-xs">
                      <span className="w-8 font-bold text-slate-600">{POS[pos].short}</span>
                      <div className="h-2 flex-1 overflow-hidden rounded-full bg-slate-100">
                        <div className="h-full rounded-full bg-ink-700" style={{ width: `${total ? (v / total) * 100 : 0}%` }} />
                      </div>
                      <span className="w-12 text-right font-semibold text-ink-900">{fmtPrice(v)}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="mt-5">
                <p className="text-[11px] font-bold uppercase tracking-widest text-slate-500">Heads-up</p>
                <ul className="mt-2 space-y-2">
                  {tips.map((t, i) => (
                    <li
                      key={i}
                      className={cn(
                        "rounded-lg px-3 py-2 text-sm",
                        t.tone === "good" && "bg-emerald-50 text-emerald-900",
                        t.tone === "warn" && "bg-amber-50 text-amber-900",
                        t.tone === "bad" && "bg-rose-50 text-rose-900",
                      )}
                    >
                      {t.text}
                    </li>
                  ))}
                </ul>
              </div>
              {Object.keys(clubs).length > 0 && (
                <div className="mt-5">
                  <p className="text-[11px] font-bold uppercase tracking-widest text-slate-500">Clubs in your squad</p>
                  <div className="mt-2 flex flex-wrap gap-1.5">
                    {Object.entries(clubs)
                      .sort((a, b) => b[1] - a[1])
                      .map(([id, n]) => (
                        <span key={id} className={cn("rounded-md px-2 py-1 text-xs font-bold", n >= MAX_PER_CLUB ? "bg-amber-100 text-amber-900" : "bg-slate-100 text-slate-700")}>
                          {teamsById[Number(id)].s} ×{n}
                        </span>
                      ))}
                  </div>
                </div>
              )}
              <p className="mt-5 text-xs text-slate-500">Guidance uses the saved official FPL data snapshot. Estimates can change and are not guaranteed points.</p>
            </Card>
          </aside>
        </div>

        {/* Submit */}
        <section id="submit-team" className="mt-8" aria-labelledby="submit-title">
          <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-ink-900 to-ink-700 p-8 text-white sm:p-10">
            <div className="grid-bg pointer-events-none absolute inset-0" />
            <div className="relative grid items-center gap-8 md:grid-cols-[1.4fr_1fr]">
              <div>
                <Eyebrow dark>Your next move</Eyebrow>
                <h2 id="submit-title" className="mt-3 font-display text-3xl font-extrabold">
                  Get your score and squad review.
                </h2>
                <p className="mt-3 text-ink-200">
                  Complete your 15-player squad to see a score out of 100, a five-part breakdown, suggested swaps and player-by-player feedback. You can copy, download or email the report.
                </p>
              </div>
              <div>
                <label htmlFor="manager" className="text-xs font-bold uppercase tracking-widest text-ink-300">
                  Manager name (optional)
                </label>
                <input
                  id="manager"
                  value={manager}
                  onChange={(e) => setManager(e.target.value)}
                  placeholder="e.g. Alex"
                  maxLength={40}
                  className="mt-2 w-full rounded-xl border border-white/15 bg-white/10 px-4 py-3 text-white placeholder:text-ink-300 focus:border-emerald-400 focus:outline-none"
                />
                <Button className="mt-3 w-full py-3.5 text-base" onClick={submit}>
                  {complete ? "Score my squad →" : `Pick ${15 - list.length} more to unlock`}
                </Button>
                <div className="mt-3 h-1.5 overflow-hidden rounded-full bg-white/10">
                  <div className="h-full rounded-full bg-emerald-400 transition-all" style={{ width: `${(list.length / 15) * 100}%` }} />
                </div>
              </div>
            </div>
          </div>
        </section>

        {review && (
          <div className="mt-8">
            <ReviewPanel
              review={review}
              state={state}
              manager={manager}
              onEdit={() => topRef.current?.scrollIntoView({ behavior: "smooth" })}
              onApplySwap={(slotId, toId) => {
                if (assign(slotId, toId)) setTimeout(() => document.getElementById("review")?.scrollIntoView({ behavior: "smooth" }), 50);
              }}
            />
          </div>
        )}
      </Container>

      {active && (
        <PlayerPicker
          slot={active}
          state={state}
          onClose={() => setActive(null)}
          onPick={(id) => assign(active.id, id)}
        />
      )}
    </div>
  );
}
