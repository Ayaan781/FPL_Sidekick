import { Button, Card, Container, Eyebrow, SectionHeading } from "../components/ui";

const SCORING: [string, string][] = [
  ["Playing up to 60 minutes", "1 pt"],
  ["Playing 60+ minutes", "2 pts"],
  ["Goal — goalkeeper or defender", "6 pts"],
  ["Goal — midfielder", "5 pts"],
  ["Goal — forward", "4 pts"],
  ["Assist", "3 pts"],
  ["Clean sheet — goalkeeper or defender", "4 pts"],
  ["Clean sheet — midfielder", "1 pt"],
  ["Every 3 saves (goalkeeper)", "1 pt"],
  ["Penalty save", "5 pts"],
  ["Bonus points (best three in each match)", "1–3 pts"],
  ["Penalty miss", "−2 pts"],
  ["Every 2 goals conceded (GKP / DEF)", "−1 pt"],
  ["Yellow card", "−1 pt"],
  ["Own goal", "−2 pts"],
  ["Red card", "−3 pts"],
];

const CHIPS = [
  { n: "Wildcard", d: "Make unlimited free transfers in one gameweek to rebuild your squad. Available once in each half of the season.", c: "bg-sky-50 ring-sky-200 text-sky-900" },
  { n: "Free Hit", d: "A one-week transfer reset. Your squad returns to normal the following gameweek — perfect for blanks and doubles.", c: "bg-violet-50 ring-violet-200 text-violet-900" },
  { n: "Bench Boost", d: "Points from your four bench players count as well as your starting XI for one gameweek.", c: "bg-amber-50 ring-amber-200 text-amber-900" },
  { n: "Triple Captain", d: "Your captain scores triple points instead of double for one gameweek. Best used on a player with a double gameweek.", c: "bg-rose-50 ring-rose-200 text-rose-900" },
];

const TIPS = [
  { t: "Check fixtures three gameweeks ahead", d: "A great player facing tough opponents can be a worse pick than a good player with an easy run." },
  { t: "Never ignore minutes", d: "Points need playing time. Players with few minutes are rotation risks, however good their price looks." },
  { t: "Bench with purpose", d: "A bench that actually plays protects you when a starter is injured, rotated or suspended." },
  { t: "Be patient with transfers", d: "Every extra transfer beyond your free ones costs 4 points. Avoid knee-jerk reactions to a single bad week." },
  { t: "Watch the price changes", d: "Players rise and fall in price based on demand. Buying a riser early builds team value you can reinvest." },
  { t: "Captain on form and fixtures", d: "Pick a nailed-on starter at home to a weaker side. Expected points are a handy tiebreaker." },
];

const GLOSSARY: [string, string][] = [
  ["Form", "A player's average points per match over the last 30 days."],
  ["xPts", "Official expected points for the next gameweek, shown on the player list."],
  ["FDR", "Fixture Difficulty Rating from 1 (easiest) to 5 (hardest)."],
  ["Differential", "A player owned by few managers — a way to gain ground on rivals."],
  ["Template", "The most commonly owned players, picked by a large share of the game."],
  ["Blank / Double", "A gameweek where a team has no match (blank) or two matches (double)."],
  ["Selected by %", "The share of all FPL managers who currently own that player."],
  ["Points per £m", "Total points divided by price — a simple measure of value."],
];

export default function Guide() {
  return (
    <div>
      <section className="relative overflow-hidden bg-ink-900 text-white">
        <div className="grid-bg pointer-events-none absolute inset-0" />
        <Container className="relative py-14 sm:py-20">
          <Eyebrow dark>New to FPL? Start here</Eyebrow>
          <h1 className="mt-3 max-w-3xl font-display text-4xl font-extrabold leading-tight sm:text-5xl">
            The Fantasy Premier League <span className="text-emerald-400">guide.</span>
          </h1>
          <p className="mt-4 max-w-2xl text-ink-200">Everything you need to know to build, manage and improve your squad — rules, scoring, chips and a few habits of successful managers.</p>
        </Container>
      </section>

      <Container className="space-y-20 py-16">
        {/* Rules */}
        <div>
          <SectionHeading eyebrow="The rules" title="How a squad works" />
          <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {[
              { v: "£100.0m", l: "Budget", d: "Spend it across your whole 15-player squad." },
              { v: "15", l: "Players", d: "2 goalkeepers, 5 defenders, 5 midfielders, 3 forwards." },
              { v: "3", l: "Per club", d: "No more than three players from any one club." },
              { v: "11", l: "Start", d: "Pick a legal formation; four players sit on the bench." },
            ].map((r) => (
              <Card key={r.l} className="p-6">
                <p className="font-display text-4xl font-extrabold text-emerald-600">{r.v}</p>
                <h3 className="mt-1 font-bold text-ink-900">{r.l}</h3>
                <p className="mt-1 text-sm text-slate-600">{r.d}</p>
              </Card>
            ))}
          </div>
          <Card className="mt-4 p-6">
            <h3 className="font-bold text-ink-900">Legal formations</h3>
            <p className="mt-1 text-sm text-slate-600">At least 3 defenders, 2 midfielders and 1 forward must start, plus exactly 1 goalkeeper.</p>
            <div className="mt-4 flex flex-wrap gap-2">
              {["3-4-3", "3-5-2", "4-3-3", "4-4-2", "4-5-1", "5-2-3", "5-3-2", "5-4-1"].map((f) => (
                <span key={f} className="rounded-lg bg-ink-900 px-3 py-1.5 text-sm font-bold text-white">
                  {f}
                </span>
              ))}
            </div>
          </Card>
        </div>

        {/* Scoring */}
        <div className="grid gap-10 lg:grid-cols-[1fr_1.2fr]">
          <div>
            <SectionHeading eyebrow="Scoring" title="How players earn points" sub="Points are awarded for what players do on the pitch. Your captain's points count double." />
            <div className="mt-6 rounded-2xl bg-ink-900 p-6 text-white">
              <p className="text-xs font-bold uppercase tracking-widest text-emerald-300">Sidekick score (0–100)</p>
              <ul className="mt-4 space-y-2 text-sm">
                {[
                  ["Current form", 25],
                  ["Fixture run", 20],
                  ["Availability", 20],
                  ["Value & budget", 15],
                  ["Captain, bench & spread", 20],
                ].map(([l, m]) => (
                  <li key={l as string} className="flex items-center justify-between gap-4 border-b border-white/10 pb-2">
                    <span className="text-ink-100">{l}</span>
                    <span className="font-display font-bold text-emerald-300">{m}</span>
                  </li>
                ))}
              </ul>
              <p className="mt-4 text-xs text-ink-300">Our own guidance tool — separate from official FPL scoring.</p>
            </div>
          </div>
          <Card className="overflow-hidden">
            <table className="w-full text-sm">
              <thead className="bg-slate-50 text-left text-xs uppercase tracking-wide text-slate-500">
                <tr>
                  <th className="px-5 py-3 font-semibold">Action</th>
                  <th className="px-5 py-3 text-right font-semibold">Points</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {SCORING.map(([a, p]) => (
                  <tr key={a}>
                    <td className="px-5 py-2.5 text-slate-700">{a}</td>
                    <td className={`px-5 py-2.5 text-right font-bold ${p.startsWith("−") ? "text-rose-600" : "text-emerald-700"}`}>{p}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </Card>
        </div>

        {/* Chips */}
        <div>
          <SectionHeading eyebrow="Chips" title="Four power-ups, used wisely" sub="Each chip can be played once in each half of the season." />
          <div className="mt-8 grid gap-4 sm:grid-cols-2">
            {CHIPS.map((c) => (
              <div key={c.n} className={`rounded-2xl p-6 ring-1 ${c.c}`}>
                <h3 className="font-display text-xl font-bold">{c.n}</h3>
                <p className="mt-2 text-sm leading-relaxed opacity-90">{c.d}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Tips */}
        <div>
          <SectionHeading eyebrow="Habits of good managers" title="Six tips to climb the rankings" />
          <div className="mt-8 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {TIPS.map((t, i) => (
              <Card key={t.t} className="p-6">
                <span className="flex h-9 w-9 items-center justify-center rounded-full bg-emerald-100 font-display text-sm font-extrabold text-emerald-800">{i + 1}</span>
                <h3 className="mt-3 font-bold text-ink-900">{t.t}</h3>
                <p className="mt-1.5 text-sm leading-relaxed text-slate-600">{t.d}</p>
              </Card>
            ))}
          </div>
        </div>

        {/* Glossary */}
        <div>
          <SectionHeading eyebrow="Glossary" title="Terms you'll see around the app" />
          <dl className="mt-8 grid gap-x-10 gap-y-5 sm:grid-cols-2">
            {GLOSSARY.map(([t, d]) => (
              <div key={t} className="border-l-2 border-emerald-500 pl-4">
                <dt className="font-bold text-ink-900">{t}</dt>
                <dd className="text-sm text-slate-600">{d}</dd>
              </div>
            ))}
          </dl>
        </div>

        <div className="rounded-3xl bg-ink-900 p-10 text-center text-white">
          <h2 className="font-display text-3xl font-extrabold">Put it into practice</h2>
          <p className="mx-auto mt-2 max-w-lg text-ink-200">Build your squad and get an instant score with player-by-player feedback.</p>
          <a href="#/builder" className="mt-6 inline-block">
            <Button className="px-7 py-3.5 text-base">Open the team builder →</Button>
          </a>
        </div>
      </Container>
    </div>
  );
}
