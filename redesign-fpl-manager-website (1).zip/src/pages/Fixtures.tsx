import { useMemo, useState } from "react";
import { DATA, FDR_STYLE, avgFdr, fixturesOf, teams, teamsById } from "../lib/data";
import { Card, Container, Eyebrow } from "../components/ui";
import { cn } from "../utils/cn";

export default function Fixtures() {
  const [span, setSpan] = useState(5);
  const [mode, setMode] = useState<"ease" | "name">("ease");
  const gws = Array.from({ length: span }, (_, i) => DATA.nextGw + i);

  const rows = useMemo(() => {
    const r = teams.map((t) => ({ t, avg: avgFdr(t.id, span) }));
    return mode === "ease" ? r.sort((a, b) => a.avg - b.avg) : r.sort((a, b) => a.t.name.localeCompare(b.t.name));
  }, [span, mode]);

  const best = rows.slice().sort((a, b) => a.avg - b.avg).slice(0, 3);
  const worst = rows.slice().sort((a, b) => b.avg - a.avg).slice(0, 3);

  return (
    <div>
      <section className="relative overflow-hidden bg-ink-900 text-white">
        <div className="grid-bg pointer-events-none absolute inset-0" />
        <Container className="relative py-14 sm:py-20">
          <Eyebrow dark>Plan ahead</Eyebrow>
          <h1 className="mt-3 font-display text-4xl font-extrabold leading-tight sm:text-5xl">
            Fixture difficulty <span className="text-emerald-400">ticker.</span>
          </h1>
          <p className="mt-4 max-w-2xl text-ink-200">
            See which clubs have the friendliest runs and which to avoid. Difficulty is the official FPL rating from 1 (easiest) to 5 (hardest). Blanks show as “–” and doubles show two fixtures.
          </p>
        </Container>
      </section>

      <Container className="py-10">
        <div className="grid gap-4 sm:grid-cols-2">
          <Card className="p-5">
            <p className="text-xs font-bold uppercase tracking-widest text-emerald-700">Best runs · next {span}</p>
            <div className="mt-3 flex flex-wrap gap-2">
              {best.map((b) => (
                <span key={b.t.id} className="rounded-lg bg-emerald-50 px-3 py-1.5 text-sm font-bold text-emerald-800 ring-1 ring-emerald-200">
                  {b.t.name} <span className="font-medium opacity-70">{b.avg.toFixed(2)}</span>
                </span>
              ))}
            </div>
          </Card>
          <Card className="p-5">
            <p className="text-xs font-bold uppercase tracking-widest text-rose-700">Toughest runs · next {span}</p>
            <div className="mt-3 flex flex-wrap gap-2">
              {worst.map((b) => (
                <span key={b.t.id} className="rounded-lg bg-rose-50 px-3 py-1.5 text-sm font-bold text-rose-800 ring-1 ring-rose-200">
                  {b.t.name} <span className="font-medium opacity-70">{b.avg.toFixed(2)}</span>
                </span>
              ))}
            </div>
          </Card>
        </div>

        <Card className="mt-6 overflow-hidden">
          <div className="flex flex-col gap-3 border-b border-slate-100 p-4 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-center gap-2 text-sm">
              <span className="font-semibold text-slate-600">Gameweeks:</span>
              {[3, 5, 6].map((n) => (
                <button
                  key={n}
                  onClick={() => setSpan(n)}
                  className={cn("rounded-lg px-3 py-1.5 text-sm font-bold", span === n ? "bg-ink-900 text-white" : "bg-slate-100 text-slate-600 hover:bg-slate-200")}
                >
                  Next {n}
                </button>
              ))}
            </div>
            <div className="flex items-center gap-2 text-sm">
              <span className="font-semibold text-slate-600">Sort:</span>
              {(
                [
                  ["ease", "Easiest first"],
                  ["name", "A–Z"],
                ] as const
              ).map(([k, l]) => (
                <button
                  key={k}
                  onClick={() => setMode(k)}
                  className={cn("rounded-lg px-3 py-1.5 text-sm font-bold", mode === k ? "bg-emerald-500 text-ink-950" : "bg-slate-100 text-slate-600 hover:bg-slate-200")}
                >
                  {l}
                </button>
              ))}
            </div>
          </div>
          <div className="scroll-thin overflow-x-auto">
            <table className="w-full min-w-[640px] text-sm">
              <thead className="bg-slate-50 text-xs uppercase tracking-wide text-slate-500">
                <tr>
                  <th className="px-4 py-3 text-left font-semibold">Club</th>
                  {gws.map((g) => (
                    <th key={g} className="px-2 py-3 text-center font-semibold">
                      GW{g}
                    </th>
                  ))}
                  <th className="px-4 py-3 text-center font-semibold">Avg</th>
                </tr>
              </thead>
              <tbody>
                {rows.map(({ t, avg }) => {
                  const fx = fixturesOf(t.id, 40);
                  return (
                    <tr key={t.id} className="border-t border-slate-100">
                      <td className="px-4 py-2 font-semibold text-ink-900">
                        {t.name} <span className="text-xs font-normal text-slate-400">{t.s}</span>
                      </td>
                      {gws.map((g) => {
                        const m = fx.filter((f) => f.e === g);
                        return (
                          <td key={g} className="px-1 py-1.5 text-center">
                            {m.length === 0 ? (
                              <span className="inline-block w-full rounded-md bg-slate-50 py-2 text-slate-300">–</span>
                            ) : (
                              <div className="flex flex-col gap-1">
                                {m.map((f, i) => (
                                  <span
                                    key={i}
                                    title={`${f.h ? "Home" : "Away"} vs ${teamsById[f.o].name} · difficulty ${f.d}`}
                                    className={cn("block rounded-md py-1.5 text-xs font-bold", FDR_STYLE[f.d])}
                                  >
                                    {teamsById[f.o].s} <span className="font-medium opacity-70">({f.h ? "H" : "A"})</span>
                                  </span>
                                ))}
                              </div>
                            )}
                          </td>
                        );
                      })}
                      <td className="px-4 py-2 text-center font-bold text-ink-900">{avg.toFixed(2)}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          <div className="flex flex-wrap items-center gap-3 border-t border-slate-100 bg-slate-50 px-4 py-3 text-xs font-semibold text-slate-600">
            Difficulty:
            {[1, 2, 3, 4, 5].map((d) => (
              <span key={d} className={cn("rounded px-2.5 py-1", FDR_STYLE[d])}>
                {d} {d === 1 ? "· easiest" : d === 5 ? "· hardest" : ""}
              </span>
            ))}
          </div>
        </Card>
      </Container>
    </div>
  );
}
