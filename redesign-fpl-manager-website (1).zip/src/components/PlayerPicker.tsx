import { useEffect, useMemo, useRef, useState } from "react";
import { BUDGET, POS, fmtPrice, players, rating, teams, teamsById, type Player } from "../lib/data";
import { blockReason, spent, type Slot, type SquadState } from "../lib/squad";
import { cn } from "../utils/cn";
import { FixtureChips, Jersey, StatusBadge } from "./ui";

type SortKey = "rating" | "form" | "tp" | "ep" | "priceAsc" | "priceDesc" | "sel" | "value";
const SORTS: { key: SortKey; label: string }[] = [
  { key: "rating", label: "Sidekick rating" },
  { key: "form", label: "Form" },
  { key: "ep", label: "Expected pts (next GW)" },
  { key: "tp", label: "Total points" },
  { key: "value", label: "Points per £m" },
  { key: "sel", label: "Selected by %" },
  { key: "priceDesc", label: "Price: high → low" },
  { key: "priceAsc", label: "Price: low → high" },
];

const sorter: Record<SortKey, (a: Player, b: Player) => number> = {
  rating: (a, b) => rating(b) - rating(a),
  form: (a, b) => b.f - a.f || b.tp - a.tp,
  ep: (a, b) => b.ep - a.ep,
  tp: (a, b) => b.tp - a.tp,
  value: (a, b) => b.tp / b.c - a.tp / a.c,
  sel: (a, b) => b.sel - a.sel,
  priceAsc: (a, b) => a.c - b.c || b.tp - a.tp,
  priceDesc: (a, b) => b.c - a.c || b.tp - a.tp,
};

const norm = (s: string) => s.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();

export function PlayerPicker({
  slot,
  state,
  onPick,
  onClose,
}: {
  slot: Slot;
  state: SquadState;
  onPick: (id: number) => boolean;
  onClose: () => void;
}) {
  const [q, setQ] = useState("");
  const [team, setTeam] = useState(0);
  const [sort, setSort] = useState<SortKey>("rating");
  const [availOnly, setAvailOnly] = useState(false);
  const [affordOnly, setAffordOnly] = useState(false);
  const [limit, setLimit] = useState(40);
  const inputRef = useRef<HTMLInputElement>(null);

  const currentId = state.picks[slot.id] ?? null;
  const room = BUDGET - (spent(state) - (currentId ? (players.find((p) => p.id === currentId)?.c ?? 0) : 0));

  useEffect(() => {
    inputRef.current?.focus();
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = prev;
    };
  }, [onClose]);

  useEffect(() => setLimit(40), [q, team, sort, availOnly, affordOnly]);

  const list = useMemo(() => {
    const nq = norm(q.trim());
    return players
      .filter((p) => p.p === slot.pos)
      .filter((p) => !team || p.t === team)
      .filter((p) => !nq || norm(`${p.n} ${p.fn} ${p.sn} ${teamsById[p.t].name} ${teamsById[p.t].s}`).includes(nq))
      .filter((p) => !availOnly || (p.st === "a" && (p.ch === null || p.ch >= 100)))
      .filter((p) => !affordOnly || p.c <= room)
      .sort(sorter[sort]);
  }, [q, team, sort, availOnly, affordOnly, slot.pos, room]);

  return (
    <div className="fixed inset-0 z-[80] flex justify-end" role="dialog" aria-modal="true" aria-label={`Choose a ${POS[slot.pos].name}`}>
      <button className="absolute inset-0 bg-ink-950/60 backdrop-blur-sm" aria-label="Close player list" onClick={onClose} />
      <div className="pop relative flex h-full w-full max-w-2xl flex-col bg-slate-50 shadow-2xl">
        <div className="bg-ink-900 px-5 pb-4 pt-5 text-white">
          <div className="flex items-start justify-between gap-4">
            <div>
              <p className="text-xs font-bold uppercase tracking-[0.16em] text-emerald-300">
                {slot.bench ? "Bench slot" : "Starting XI"} · {POS[slot.pos].short}
              </p>
              <h3 className="mt-1 font-display text-xl font-bold">Choose a {POS[slot.pos].name.toLowerCase()}</h3>
              <p className="mt-1 text-sm text-ink-200">
                You can spend up to <b className="text-white">{fmtPrice(room)}</b> on this slot.
              </p>
            </div>
            <button onClick={onClose} className="rounded-lg p-2 text-ink-200 hover:bg-white/10 hover:text-white" aria-label="Close">
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
                <path d="M6 6l12 12M18 6L6 18" />
              </svg>
            </button>
          </div>

          <div className="mt-4 grid gap-2 sm:grid-cols-[1fr_auto_auto]">
            <div className="relative">
              <svg className="absolute left-3 top-1/2 -translate-y-1/2 text-ink-300" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
                <circle cx="11" cy="11" r="7" />
                <path d="M20 20l-3.5-3.5" />
              </svg>
              <input
                ref={inputRef}
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="Search player or club…"
                className="w-full rounded-xl border border-white/10 bg-white/10 py-2.5 pl-9 pr-3 text-sm text-white placeholder:text-ink-300 focus:border-emerald-400 focus:outline-none"
              />
            </div>
            <select
              value={team}
              onChange={(e) => setTeam(Number(e.target.value))}
              aria-label="Filter by club"
              className="rounded-xl border border-white/10 bg-ink-800 px-3 py-2.5 text-sm text-white"
            >
              <option value={0}>All clubs</option>
              {teams.map((t) => (
                <option key={t.id} value={t.id}>
                  {t.name}
                </option>
              ))}
            </select>
            <select
              value={sort}
              onChange={(e) => setSort(e.target.value as SortKey)}
              aria-label="Sort players"
              className="rounded-xl border border-white/10 bg-ink-800 px-3 py-2.5 text-sm text-white"
            >
              {SORTS.map((s) => (
                <option key={s.key} value={s.key}>
                  {s.label}
                </option>
              ))}
            </select>
          </div>
          <div className="mt-3 flex flex-wrap gap-4 text-sm text-ink-100">
            <label className="flex cursor-pointer items-center gap-2">
              <input type="checkbox" checked={availOnly} onChange={(e) => setAvailOnly(e.target.checked)} className="h-4 w-4 accent-emerald-500" />
              Fully fit only
            </label>
            <label className="flex cursor-pointer items-center gap-2">
              <input type="checkbox" checked={affordOnly} onChange={(e) => setAffordOnly(e.target.checked)} className="h-4 w-4 accent-emerald-500" />
              Affordable only
            </label>
            <span className="ml-auto text-ink-300">{list.length} players</span>
          </div>
        </div>

        <div className="scroll-thin flex-1 overflow-y-auto px-3 py-3 sm:px-5">
          {list.length === 0 && (
            <div className="mt-16 text-center text-slate-500">
              <p className="font-display text-lg font-bold text-ink-900">No players match</p>
              <p className="mt-1 text-sm">Try clearing the search or loosening a filter.</p>
            </div>
          )}
          <ul className="space-y-2">
            {list.slice(0, limit).map((p) => {
              const reason = currentId === p.id ? "Currently selected" : blockReason(state, p, slot.id);
              const blocked = !!reason;
              return (
                <li
                  key={p.id}
                  className={cn(
                    "flex items-center gap-3 rounded-xl border bg-white p-3 transition",
                    blocked ? "border-slate-200 opacity-70" : "border-slate-200 hover:border-emerald-400 hover:shadow-md",
                  )}
                >
                  <Jersey player={p} size={40} />
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
                      <span className="truncate font-semibold text-ink-900">{p.n}</span>
                      <span className="text-xs text-slate-500">{teamsById[p.t].s}</span>
                      <StatusBadge player={p} compact />
                    </div>
                    <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-slate-500">
                      <FixtureChips teamId={p.t} n={3} />
                      <span>
                        Form <b className="text-ink-900">{p.f.toFixed(1)}</b>
                      </span>
                      <span>
                        Pts <b className="text-ink-900">{p.tp}</b>
                      </span>
                      <span className="hidden sm:inline">
                        xPts <b className="text-ink-900">{p.ep.toFixed(1)}</b>
                      </span>
                      <span className="hidden sm:inline">
                        Sel <b className="text-ink-900">{p.sel.toFixed(1)}%</b>
                      </span>
                    </div>
                    {reason && <p className={cn("mt-1 text-xs font-medium", currentId === p.id ? "text-emerald-700" : "text-rose-600")}>{reason}</p>}
                  </div>
                  <div className="text-right">
                    <div className="font-display text-sm font-bold text-ink-900">{fmtPrice(p.c)}</div>
                    <button
                      disabled={blocked}
                      onClick={() => onPick(p.id) && onClose()}
                      className="mt-1 rounded-lg bg-emerald-500 px-3 py-1.5 text-xs font-bold text-ink-950 transition hover:bg-emerald-400 disabled:cursor-not-allowed disabled:bg-slate-200 disabled:text-slate-400"
                    >
                      {currentId === p.id ? "Picked" : "Add"}
                    </button>
                  </div>
                </li>
              );
            })}
          </ul>
          {list.length > limit && (
            <button
              onClick={() => setLimit((l) => l + 40)}
              className="mx-auto mt-4 block rounded-xl border border-slate-300 bg-white px-5 py-2.5 text-sm font-semibold text-ink-900 hover:bg-slate-50"
            >
              Show {Math.min(40, list.length - limit)} more
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
