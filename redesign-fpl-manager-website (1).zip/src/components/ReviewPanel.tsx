import { useEffect, useState } from "react";
import { POS, fmtPrice, teamsById } from "../lib/data";
import { effectiveCaptains, reportText, type Review, type SquadState } from "../lib/squad";
import { cn } from "../utils/cn";
import { useToast } from "../lib/hooks";
import { Button, Card, Eyebrow, Jersey } from "./ui";

function ScoreRing({ score }: { score: number }) {
  const [shown, setShown] = useState(0);
  useEffect(() => {
    let raf = 0;
    const start = performance.now();
    const tick = (t: number) => {
      const k = Math.min(1, (t - start) / 1200);
      setShown(Math.round((1 - Math.pow(1 - k, 3)) * score));
      if (k < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [score]);
  const r = 78;
  const c = 2 * Math.PI * r;
  const color = score >= 72 ? "#34d399" : score >= 58 ? "#fbbf24" : "#fb7185";
  return (
    <div className="relative h-52 w-52 shrink-0">
      <svg viewBox="0 0 180 180" className="h-full w-full -rotate-90">
        <circle cx="90" cy="90" r={r} stroke="rgba(255,255,255,0.1)" strokeWidth="12" fill="none" />
        <circle
          cx="90"
          cy="90"
          r={r}
          stroke={color}
          strokeWidth="12"
          fill="none"
          strokeLinecap="round"
          strokeDasharray={c}
          strokeDashoffset={c * (1 - shown / 100)}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="font-display text-6xl font-extrabold text-white">{shown}</span>
        <span className="text-xs font-semibold uppercase tracking-widest text-ink-300">out of 100</span>
      </div>
    </div>
  );
}

const toneDot = { good: "bg-emerald-500", warn: "bg-amber-500", bad: "bg-rose-500" } as const;
const toneText = { good: "text-slate-700", warn: "text-amber-800", bad: "text-rose-700" } as const;

export function ReviewPanel({
  review,
  state,
  manager,
  onEdit,
  onApplySwap,
}: {
  review: Review;
  state: SquadState;
  manager: string;
  onEdit: () => void;
  onApplySwap: (slotId: string, toId: number) => void;
}) {
  const toast = useToast();
  const { captain, vice } = effectiveCaptains(state);
  const text = reportText(state, review, manager.trim() || undefined);

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(text);
      toast("Report copied to your clipboard.", "success");
    } catch {
      toast("Couldn't copy automatically — try the download instead.", "error");
    }
  };
  const download = () => {
    const url = URL.createObjectURL(new Blob([text], { type: "text/plain" }));
    const a = document.createElement("a");
    a.href = url;
    a.download = `fpl-sidekick-review-${review.score}.txt`;
    a.click();
    URL.revokeObjectURL(url);
    toast("Report downloaded.", "success");
  };
  const mail = () => {
    const href = `mailto:?subject=${encodeURIComponent(`My FPL squad scored ${review.score}/100`)}&body=${encodeURIComponent(text.slice(0, 1800))}`;
    window.location.href = href;
  };

  return (
    <section id="review" className="fade-up scroll-mt-24" aria-labelledby="review-title">
      <div className="overflow-hidden rounded-3xl bg-ink-900 text-white shadow-2xl shadow-ink-900/20">
        <div className="relative px-6 py-10 sm:px-10">
          <div className="grid-bg pointer-events-none absolute inset-0" />
          <div className="relative flex flex-col items-center gap-8 md:flex-row">
            <ScoreRing score={review.score} />
            <div className="text-center md:text-left">
              <Eyebrow dark>Your squad review{manager.trim() ? ` · ${manager.trim()}` : ""}</Eyebrow>
              <h2 id="review-title" className="mt-2 font-display text-3xl font-extrabold sm:text-4xl">
                {review.grade} squad
              </h2>
              <p className="mt-2 max-w-xl text-ink-200">{review.headline}</p>
              <div className="mt-5 flex flex-wrap justify-center gap-2 md:justify-start">
                <Button onClick={copy}>Copy report</Button>
                <Button variant="outline" onClick={download}>
                  Download .txt
                </Button>
                <Button variant="outline" onClick={mail}>
                  Share by email
                </Button>
                <Button variant="ghost" className="text-white hover:bg-white/10" onClick={onEdit}>
                  ↑ Edit squad
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-5">
        <Card className="p-6 lg:col-span-3">
          <h3 className="font-display text-lg font-bold text-ink-900">Score breakdown</h3>
          <div className="mt-5 space-y-5">
            {review.categories.map((c) => {
              const ratio = c.score / c.max;
              return (
                <div key={c.key}>
                  <div className="flex items-baseline justify-between">
                    <span className="text-sm font-semibold text-ink-900">{c.label}</span>
                    <span className="text-sm font-bold text-ink-900">
                      {c.score.toFixed(1)}
                      <span className="font-medium text-slate-400"> / {c.max}</span>
                    </span>
                  </div>
                  <div className="mt-2 h-2.5 overflow-hidden rounded-full bg-slate-100">
                    <div
                      className={cn("h-full rounded-full transition-all duration-1000", ratio >= 0.75 ? "bg-emerald-500" : ratio >= 0.45 ? "bg-amber-400" : "bg-rose-500")}
                      style={{ width: `${Math.max(3, ratio * 100)}%` }}
                    />
                  </div>
                  <p className="mt-2 text-sm text-slate-700">{c.verdict}</p>
                  <p className="text-xs text-slate-500">{c.tip}</p>
                </div>
              );
            })}
          </div>
        </Card>

        <div className="space-y-6 lg:col-span-2">
          <Card className="p-6">
            <h3 className="font-display text-lg font-bold text-ink-900">Best moves to make</h3>
            {review.topMoves.length === 0 ? (
              <p className="mt-3 text-sm text-slate-600">No obvious upgrades available inside your budget — your squad is in good shape.</p>
            ) : (
              <ul className="mt-4 space-y-3">
                {review.topMoves.map((m) => {
                  const slot = review.players.find((p) => p.player.id === m.from.id)!.slot;
                  return (
                    <li key={m.from.id} className="rounded-xl border border-slate-200 p-3">
                      <div className="flex items-center gap-2 text-sm">
                        <Jersey player={m.from} size={28} />
                        <span className="font-semibold text-slate-500 line-through decoration-rose-400">{m.from.n}</span>
                        <span className="text-slate-400">→</span>
                        <Jersey player={m.to} size={28} />
                        <span className="font-bold text-ink-900">{m.to.n}</span>
                      </div>
                      <p className="mt-1.5 text-xs text-slate-500">
                        {teamsById[m.to.t].s} · {fmtPrice(m.to.c)} · form {m.to.f.toFixed(1)} · {m.to.ep.toFixed(1)} xPts
                      </p>
                      <button
                        onClick={() => onApplySwap(slot.id, m.to.id)}
                        className="mt-2 text-xs font-bold text-emerald-700 hover:text-emerald-600"
                      >
                        Make this swap →
                      </button>
                    </li>
                  );
                })}
              </ul>
            )}
          </Card>
          {review.captainPick && (
            <Card className="p-6">
              <h3 className="font-display text-lg font-bold text-ink-900">Captain check</h3>
              <p className="mt-2 text-sm text-slate-700">
                Highest projected in your XI: <b>{review.captainPick.n}</b> ({review.captainPick.ep.toFixed(1)} xPts).
                {captain === review.captainPick.id
                  ? " That's your captain — great call."
                  : captain
                    ? ` You've picked ${state.captain && review.players.find((p) => p.player.id === captain)?.player.n}; consider switching.`
                    : " You haven't chosen a captain yet."}
              </p>
              <p className="mt-1 text-xs text-slate-500">Vice-captain: {vice ? review.players.find((p) => p.player.id === vice)?.player.n : "not set"}</p>
            </Card>
          )}
        </div>
      </div>

      <Card className="mt-6 p-6">
        <h3 className="font-display text-lg font-bold text-ink-900">Player-by-player feedback</h3>
        <div className="mt-5 grid gap-3 md:grid-cols-2">
          {review.players.map((pr) => (
            <div key={pr.slot.id} className="rounded-xl border border-slate-200 p-4">
              <div className="flex items-center gap-3">
                <Jersey player={pr.player} size={38} />
                <div className="min-w-0 flex-1">
                  <p className="truncate font-semibold text-ink-900">
                    {pr.player.n}
                    {pr.player.id === captain && <span className="ml-2 rounded bg-ink-900 px-1.5 py-0.5 text-[10px] font-bold text-white">C</span>}
                    {pr.player.id === vice && <span className="ml-2 rounded bg-slate-200 px-1.5 py-0.5 text-[10px] font-bold text-ink-900">VC</span>}
                  </p>
                  <p className="text-xs text-slate-500">
                    {POS[pr.player.p].short} · {teamsById[pr.player.t].name} · {fmtPrice(pr.player.c)} · {pr.slot.bench ? "Bench" : "Starting XI"}
                  </p>
                </div>
              </div>
              <ul className="mt-3 space-y-1.5">
                {pr.notes.map((n, i) => (
                  <li key={i} className={cn("flex gap-2 text-sm", toneText[n.tone])}>
                    <span className={cn("mt-1.5 h-2 w-2 shrink-0 rounded-full", toneDot[n.tone])} />
                    {n.text}
                  </li>
                ))}
              </ul>
              {pr.swap && (
                <button
                  onClick={() => onApplySwap(pr.slot.id, pr.swap!.to.id)}
                  className="mt-3 w-full rounded-lg bg-emerald-50 px-3 py-2 text-left text-xs font-semibold text-emerald-800 ring-1 ring-emerald-200 transition hover:bg-emerald-100"
                >
                  Consider {pr.swap.to.n} ({teamsById[pr.swap.to.t].s}, {fmtPrice(pr.swap.to.c)}) — swap now
                </button>
              )}
            </div>
          ))}
        </div>
      </Card>
      <p className="mt-4 text-center text-xs text-slate-500">
        Reviews use the saved official FPL data snapshot. Estimates can change and are not guaranteed points.
      </p>
    </section>
  );
}
