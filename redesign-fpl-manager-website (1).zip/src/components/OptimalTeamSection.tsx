import { useLiveOptimalTeam } from "../lib/hooks";
import { POS, fmtDate, fmtPrice, teamsById, type Pos } from "../lib/data";
import type { OptimalPlayer, OptimalTeam } from "../lib/optimal";
import { cn } from "../utils/cn";
import { Button, Container, FixtureChips, Jersey, SectionHeading } from "./ui";

function PlayerLine({ player, team }: { player: OptimalPlayer; team: OptimalTeam }) {
  const club = team.teamNames[player.t] ?? teamsById[player.t];
  const fixtures = team.fixtures[String(player.t)] ?? [];
  const isCaptain = team.captain.id === player.id;
  const isVice = team.vice.id === player.id;
  return (
    <div className="flex items-center gap-3 rounded-xl border border-white/10 bg-white/[0.06] p-3 transition hover:bg-white/10">
      <div className="relative shrink-0">
        <Jersey player={player} size={40} />
        {(isCaptain || isVice) && (
          <span className="absolute -right-1 -top-1 flex h-5 w-5 items-center justify-center rounded-full border-2 border-ink-900 bg-amber-400 text-[10px] font-extrabold text-ink-950">
            {isCaptain ? "C" : "V"}
          </span>
        )}
      </div>
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-2">
          <p className="truncate text-sm font-bold text-white">{player.n}</p>
          {(isCaptain || isVice) && <span className="text-[10px] font-bold uppercase tracking-wider text-amber-300">{isCaptain ? "Captain" : "Vice"}</span>}
        </div>
        <p className="mt-0.5 truncate text-xs text-ink-300">
          {club?.short ?? "Club"} · {fmtPrice(player.c)}
        </p>
        <FixtureChips teamId={player.t} fixtures={fixtures} teamNames={team.teamNames} n={1} className="mt-1" />
      </div>
      <div className="text-right">
        <p className="font-display text-lg font-extrabold text-emerald-300">{player.projected.toFixed(1)}</p>
        <p className="text-[10px] font-semibold uppercase tracking-wider text-ink-400">xPts</p>
      </div>
    </div>
  );
}

function PositionGroup({ pos, team }: { pos: Pos; team: OptimalTeam }) {
  const players = team.xi.filter((player) => player.p === pos);
  return (
    <div>
      <div className="mb-2 flex items-center justify-between">
        <p className="text-[11px] font-bold uppercase tracking-[0.18em] text-emerald-300">{POS[pos].plural}</p>
        <span className="text-xs text-ink-400">{players.length} starter{players.length === 1 ? "" : "s"}</span>
      </div>
      <div className="space-y-2">
        {players.map((player) => <PlayerLine key={player.id} player={player} team={team} />)}
      </div>
    </div>
  );
}

export default function OptimalTeamSection() {
  const { team, loading, error, refresh } = useLiveOptimalTeam();
  const updatedTime = new Date(team.updatedAt).toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" });
  const live = team.source === "live";

  return (
    <section id="optimal-xi" className="border-y border-slate-200 bg-ink-950 py-20 text-white sm:py-24">
      <Container>
        <div className="flex flex-col justify-between gap-5 lg:flex-row lg:items-end">
          <SectionHeading
            dark
            eyebrow="The data-led starting point"
            title={<>The optimum team for <span className="text-emerald-400">GW{team.gameweek}.</span></>}
            sub="A legal 15-player squad chosen for the next deadline, then shaped into the formation with the highest projected starting-XI points."
          />
          <div className="flex shrink-0 flex-wrap items-center gap-3">
            <span className={cn("inline-flex items-center gap-2 rounded-full px-3 py-2 text-xs font-bold", live ? "bg-emerald-400/15 text-emerald-300" : "bg-amber-400/15 text-amber-200")}>
              <span className={cn("h-2 w-2 rounded-full", live ? "bg-emerald-400 pulse-ring" : "bg-amber-400")} />
              {live ? "Live official FPL feed" : "Latest saved snapshot"}
            </span>
            <Button variant="outline" onClick={() => void refresh()} disabled={loading} className="border-white/20 bg-white/5 text-white hover:bg-white/10 hover:text-white">
              <svg className={cn(loading && "animate-spin")} width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
                <path d="M20 11a8.1 8.1 0 00-14.8-3L3 11m0 0V5m0 6h6M4 13a8.1 8.1 0 0014.8 3L21 13m0 0v6m0-6h-6" />
              </svg>
              {loading ? "Updating…" : "Refresh now"}
            </Button>
          </div>
        </div>

        {error && <p className="mt-4 rounded-xl border border-amber-300/20 bg-amber-300/10 px-4 py-3 text-sm text-amber-100">{error}</p>}

        <div className="mt-10 grid gap-6 lg:grid-cols-[1.25fr_.75fr]">
          <div className="rounded-3xl bg-ink-900 p-5 shadow-2xl shadow-black/20 sm:p-7">
            <div className="flex flex-col justify-between gap-4 border-b border-white/10 pb-5 sm:flex-row sm:items-center">
              <div>
                <p className="text-xs font-bold uppercase tracking-widest text-ink-300">Best starting XI</p>
                <p className="mt-1 font-display text-2xl font-extrabold">{team.formation} formation</p>
              </div>
              <div className="flex gap-2 text-center">
                <div className="rounded-xl bg-white/5 px-3 py-2">
                  <p className="font-display text-lg font-bold text-emerald-300">{team.projected.toFixed(1)}</p>
                  <p className="text-[10px] font-semibold uppercase tracking-wider text-ink-400">projected w/C</p>
                </div>
                <div className="rounded-xl bg-white/5 px-3 py-2">
                  <p className="font-display text-lg font-bold text-white">{fmtPrice(team.spend)}</p>
                  <p className="text-[10px] font-semibold uppercase tracking-wider text-ink-400">squad spend</p>
                </div>
              </div>
            </div>
            <div className="mt-5 grid gap-5 sm:grid-cols-2">
              {([1, 2, 3, 4] as Pos[]).map((pos) => <PositionGroup key={pos} pos={pos} team={team} />)}
            </div>
          </div>

          <div className="flex flex-col rounded-3xl bg-white p-6 text-ink-900 sm:p-7">
            <div className="flex items-start justify-between gap-3">
              <div>
                <p className="text-xs font-bold uppercase tracking-widest text-emerald-700">Cover on the bench</p>
                <h3 className="mt-1 font-display text-2xl font-extrabold">Four supporting picks</h3>
              </div>
              <span className="rounded-lg bg-slate-100 px-2 py-1 text-xs font-bold text-slate-600">{team.squad.length}/15</span>
            </div>
            <div className="mt-5 space-y-2">
              {team.bench.map((player, index) => {
                const club = team.teamNames[player.t] ?? teamsById[player.t];
                return (
                  <div key={player.id} className="flex items-center gap-3 rounded-xl bg-slate-50 p-3">
                    <span className="w-4 text-center text-xs font-bold text-slate-400">{index + 1}</span>
                    <Jersey player={player} size={34} />
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-bold">{player.n}</p>
                      <p className="text-xs text-slate-500">{POS[player.p].short} · {club?.short ?? "Club"} · {fmtPrice(player.c)}</p>
                    </div>
                    <span className="font-display text-sm font-bold text-emerald-700">{player.projected.toFixed(1)}</span>
                  </div>
                );
              })}
            </div>
            <div className="mt-6 border-t border-slate-200 pt-5">
              <p className="text-xs font-bold uppercase tracking-widest text-slate-500">Why these picks?</p>
              <p className="mt-2 text-sm leading-relaxed text-slate-600">
                The optimiser uses official expected points, current availability, fixture difficulty and minutes played, while enforcing the £100m budget and max-three-per-club rule. Captain {team.captain.n} is projected highest in this XI; {team.vice.n} is vice-captain.
              </p>
              <a href="#/builder" className="mt-5 inline-flex text-sm font-bold text-emerald-700 hover:text-emerald-600">Use it as your starting point in the builder →</a>
            </div>
            <p className="mt-auto pt-6 text-xs text-slate-400">
              {live ? `Live data refreshed at ${updatedTime}` : `Snapshot from ${fmtDate(team.updatedAt)}`} · Next deadline {fmtDate(team.deadline, { weekday: "short", day: "numeric", month: "short" })}
            </p>
          </div>
        </div>
        <p className="mt-5 text-center text-xs text-ink-400">Updates on page focus and every 5 minutes. Projected points are guidance, not guaranteed results.</p>
      </Container>
    </section>
  );
}