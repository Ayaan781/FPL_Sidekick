import { useEffect, useState, type ReactNode } from "react";
import { cn } from "../utils/cn";
import {
  DATA,
  FDR_STYLE,
  GK_KIT,
  KITS,
  fixturesOf,
  fmtDate,
  statusLabel,
  teamsById,
  type Fixture,
  type Player,
} from "../lib/data";

/* ---------- Logo ---------- */
export function Logo({ light = true }: { light?: boolean }) {
  return (
    <a href="#/" className="group flex items-center gap-2.5" aria-label="FPL Sidekick home">
      <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-emerald-400 to-emerald-600 shadow-lg shadow-emerald-900/30 transition-transform group-hover:scale-105">
        <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="#06132a" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round">
          <path d="M4 17l5-10 4 7 3-5 4 8" />
        </svg>
      </span>
      <span className={cn("font-display text-lg font-bold tracking-tight", light ? "text-white" : "text-ink-900")}>
        FPL <span className="text-emerald-400">Sidekick</span>
      </span>
    </a>
  );
}

/* ---------- Jersey ---------- */
export function Jersey({ player, size = 44 }: { player: Pick<Player, "t" | "p">; size?: number }) {
  const short = teamsById[player.t]?.s;
  const [body, trim] = player.p === 1 ? GK_KIT : (KITS[short] ?? ["#94a3b8", "#fff"]);
  return (
    <svg width={size} height={size} viewBox="0 0 48 48" aria-hidden className="drop-shadow-[0_2px_2px_rgba(0,0,0,0.35)]">
      <path
        d="M17 5 L7 10 L2 21 L10 25 L13 20 L13 43 L35 43 L35 20 L38 25 L46 21 L41 10 L31 5 C29 9 19 9 17 5Z"
        fill={body}
        stroke="rgba(15,23,42,0.35)"
        strokeWidth="1.2"
        strokeLinejoin="round"
      />
      <path d="M2 21 L10 25 L13 20 L12 14 L7 10Z" fill={trim} opacity="0.95" />
      <path d="M46 21 L38 25 L35 20 L36 14 L41 10Z" fill={trim} opacity="0.95" />
      <path d="M17 5 C19 9 29 9 31 5 L29 4 C27 6.5 21 6.5 19 4Z" fill={trim} />
    </svg>
  );
}

/* ---------- Fixture chips ---------- */
export function FixtureChips({
  teamId,
  n = 3,
  className,
  fixtures,
  teamNames,
}: {
  teamId: number;
  n?: number;
  className?: string;
  fixtures?: Fixture[];
  teamNames?: Record<number, { name: string; short: string }>;
}) {
  const fx = (fixtures ?? fixturesOf(teamId, n)).slice(0, n);
  if (!fx.length) return <span className="text-xs text-slate-400">No fixtures</span>;
  return (
    <span className={cn("inline-flex gap-1", className)}>
      {fx.map((f, i) => {
        const liveOpponent = teamNames?.[f.o];
        const opponent = teamsById[f.o];
        return (
          <span
            key={i}
            title={`GW${f.e}: ${f.h ? "Home" : "Away"} vs ${liveOpponent?.name ?? opponent?.name ?? "Opponent"} (difficulty ${f.d}/5)`}
            className={cn("rounded px-1.5 py-0.5 text-[10px] font-bold leading-tight", FDR_STYLE[f.d])}
          >
            {liveOpponent?.short ?? opponent?.s ?? "TBC"}
            <span className="font-medium opacity-70">{f.h ? " (H)" : " (A)"}</span>
          </span>
        );
      })}
    </span>
  );
}

/* ---------- Status badge ---------- */
export function StatusBadge({ player, compact }: { player: Player; compact?: boolean }) {
  const s = statusLabel(player);
  if (s.tone === "ok" && compact) return null;
  const cls = {
    ok: "bg-emerald-50 text-emerald-700 ring-emerald-200",
    warn: "bg-amber-50 text-amber-800 ring-amber-200",
    bad: "bg-rose-50 text-rose-700 ring-rose-200",
  }[s.tone];
  return (
    <span className={cn("inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[11px] font-semibold ring-1", cls)}>
      <span className={cn("h-1.5 w-1.5 rounded-full", { ok: "bg-emerald-500", warn: "bg-amber-500", bad: "bg-rose-500" }[s.tone])} />
      {s.text}
    </span>
  );
}

/* ---------- Layout bits ---------- */
export const Container = ({ children, className }: { children: ReactNode; className?: string }) => (
  <div className={cn("mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8", className)}>{children}</div>
);

export function Eyebrow({ children, dark }: { children: ReactNode; dark?: boolean }) {
  return (
    <p
      className={cn(
        "inline-flex items-center gap-2 text-xs font-bold uppercase tracking-[0.18em]",
        dark ? "text-emerald-300" : "text-emerald-700",
      )}
    >
      <span className={cn("h-1.5 w-1.5 rounded-full", dark ? "bg-emerald-400" : "bg-emerald-500")} />
      {children}
    </p>
  );
}

export function SectionHeading({
  eyebrow,
  title,
  sub,
  dark,
  center,
}: {
  eyebrow: string;
  title: ReactNode;
  sub?: ReactNode;
  dark?: boolean;
  center?: boolean;
}) {
  return (
    <div className={cn("max-w-2xl", center && "mx-auto text-center")}>
      <Eyebrow dark={dark}>{eyebrow}</Eyebrow>
      <h2 className={cn("mt-3 text-3xl font-extrabold leading-tight sm:text-4xl", dark ? "text-white" : "text-ink-900")}>{title}</h2>
      {sub && <p className={cn("mt-3 text-base leading-relaxed", dark ? "text-ink-200" : "text-slate-600")}>{sub}</p>}
    </div>
  );
}

export const Card = ({ children, className }: { children: ReactNode; className?: string }) => (
  <div className={cn("rounded-2xl border border-slate-200 bg-white shadow-sm", className)}>{children}</div>
);

export function Button({
  children,
  variant = "primary",
  className,
  ...rest
}: React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: "primary" | "dark" | "ghost" | "outline" | "danger" }) {
  const v = {
    primary: "bg-emerald-500 text-ink-950 hover:bg-emerald-400 shadow-lg shadow-emerald-500/20",
    dark: "bg-ink-900 text-white hover:bg-ink-800",
    ghost: "text-slate-600 hover:bg-slate-100",
    outline: "border border-slate-300 bg-white text-ink-900 hover:border-ink-400 hover:bg-slate-50",
    danger: "border border-rose-200 bg-white text-rose-700 hover:bg-rose-50",
  }[variant];
  return (
    <button
      {...rest}
      className={cn(
        "inline-flex items-center justify-center gap-2 rounded-xl px-4 py-2.5 text-sm font-semibold transition active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-50",
        v,
        className,
      )}
    >
      {children}
    </button>
  );
}

/* ---------- Nav ---------- */
const LINKS = [
  { href: "/", label: "Home" },
  { href: "/builder", label: "Team Builder" },
  { href: "/insights", label: "Player Insights" },
  { href: "/fixtures", label: "Fixtures" },
  { href: "/guide", label: "Guide" },
];

export function Nav({ route }: { route: string }) {
  const [open, setOpen] = useState(false);
  useEffect(() => setOpen(false), [route]);
  return (
    <header className="sticky top-0 z-50 border-b border-white/10 bg-ink-950/90 backdrop-blur-xl">
      <Container className="flex h-16 items-center justify-between">
        <Logo />
        <nav className="hidden items-center gap-1 md:flex" aria-label="Main">
          {LINKS.map((l) => (
            <a
              key={l.href}
              href={`#${l.href}`}
              aria-current={route === l.href ? "page" : undefined}
              className={cn(
                "rounded-lg px-3 py-2 text-sm font-medium transition",
                route === l.href ? "bg-white/10 text-white" : "text-ink-200 hover:bg-white/5 hover:text-white",
              )}
            >
              {l.label}
            </a>
          ))}
        </nav>
        <div className="flex items-center gap-2">
          <a
            href="#/builder"
            className="hidden rounded-xl bg-emerald-500 px-4 py-2 text-sm font-semibold text-ink-950 transition hover:bg-emerald-400 sm:inline-block"
          >
            Build my squad
          </a>
          <button
            className="rounded-lg p-2 text-white hover:bg-white/10 md:hidden"
            aria-label="Toggle menu"
            aria-expanded={open}
            onClick={() => setOpen((o) => !o)}
          >
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
              {open ? <path d="M6 6l12 12M18 6L6 18" /> : <path d="M4 7h16M4 12h16M4 17h16" />}
            </svg>
          </button>
        </div>
      </Container>
      {open && (
        <div className="border-t border-white/10 bg-ink-950 md:hidden">
          <Container className="flex flex-col gap-1 py-3">
            {LINKS.map((l) => (
              <a
                key={l.href}
                href={`#${l.href}`}
                className={cn(
                  "rounded-lg px-3 py-2.5 text-sm font-medium",
                  route === l.href ? "bg-white/10 text-white" : "text-ink-200 hover:bg-white/5",
                )}
              >
                {l.label}
              </a>
            ))}
          </Container>
        </div>
      )}
    </header>
  );
}

export function Footer() {
  return (
    <footer className="mt-24 bg-ink-950 text-ink-300">
      <Container className="grid gap-10 py-14 md:grid-cols-4">
        <div className="md:col-span-2">
          <Logo />
          <p className="mt-4 max-w-md text-sm leading-relaxed">
            Your Fantasy Premier League decision desk. Build a legal 15-player squad, see the official numbers behind every pick, and
            get a clear first read on what to improve before the deadline.
          </p>
          <p className="mt-4 text-xs text-ink-400">
            Data snapshot: {fmtDate(DATA.generated)} · Gameweek {DATA.nextGw} deadline {fmtDate(DATA.nextDeadline, { day: "numeric", month: "short" })}
          </p>
        </div>
        <div>
          <h4 className="font-display text-sm font-bold text-white">Explore</h4>
          <ul className="mt-4 space-y-2.5 text-sm">
            {LINKS.map((l) => (
              <li key={l.href}>
                <a href={`#${l.href}`} className="transition hover:text-emerald-300">
                  {l.label}
                </a>
              </li>
            ))}
          </ul>
        </div>
        <div>
          <h4 className="font-display text-sm font-bold text-white">Good to know</h4>
          <ul className="mt-4 space-y-2.5 text-sm">
            <li>Prices, form and fixtures come from official FPL data.</li>
            <li>Estimates are guidance, never guaranteed points.</li>
            <li>Your squad is saved privately in this browser.</li>
          </ul>
        </div>
      </Container>
      <div className="border-t border-white/10">
        <Container className="flex flex-col gap-2 py-5 text-xs text-ink-400 sm:flex-row sm:justify-between">
          <span>© {new Date().getFullYear()} FPL Sidekick. An independent fan project.</span>
          <span>Not affiliated with or endorsed by the Premier League.</span>
        </Container>
      </div>
    </footer>
  );
}
