import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { emptySquad, allSlots, autoPick, blockReason, effectiveCaptains, type SquadState } from "./squad";
import { playersById } from "./data";
import { fetchOptimalTeam, snapshotOptimalTeam, type OptimalTeam } from "./optimal";

/* ---------------- Toasts ---------------- */
type ToastTone = "success" | "error" | "info" | "warn";
interface ToastItem {
  id: number;
  text: string;
  tone: ToastTone;
}
const ToastCtx = createContext<(text: string, tone?: ToastTone) => void>(() => {});
export const useToast = () => useContext(ToastCtx);

export function ToastProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<ToastItem[]>([]);
  const idRef = useRef(0);
  const push = useCallback((text: string, tone: ToastTone = "info") => {
    const id = ++idRef.current;
    setItems((x) => [...x.slice(-3), { id, text, tone }]);
    window.setTimeout(() => setItems((x) => x.filter((t) => t.id !== id)), 3800);
  }, []);
  const styles: Record<ToastTone, string> = {
    success: "border-emerald-400/40 bg-emerald-950 text-emerald-50",
    error: "border-rose-400/40 bg-rose-950 text-rose-50",
    warn: "border-amber-400/40 bg-amber-950 text-amber-50",
    info: "border-sky-400/40 bg-ink-900 text-white",
  };
  const dot: Record<ToastTone, string> = {
    success: "bg-emerald-400",
    error: "bg-rose-400",
    warn: "bg-amber-400",
    info: "bg-sky-400",
  };
  return (
    <ToastCtx.Provider value={push}>
      {children}
      <div
        className="pointer-events-none fixed inset-x-0 bottom-4 z-[100] flex flex-col items-center gap-2 px-4"
        role="status"
        aria-live="polite"
      >
        {items.map((t) => (
          <div
            key={t.id}
            className={`toast-in pointer-events-auto flex max-w-md items-center gap-3 rounded-xl border px-4 py-3 text-sm font-medium shadow-2xl shadow-black/30 ${styles[t.tone]}`}
          >
            <span className={`h-2 w-2 shrink-0 rounded-full ${dot[t.tone]}`} />
            {t.text}
          </div>
        ))}
      </div>
    </ToastCtx.Provider>
  );
}

/* ---------------- Hash router ---------------- */
export function useRoute() {
  const read = () => {
    const hash = window.location.hash.replace(/^#/, "");
    return (hash.startsWith("/") ? hash : "/").split("?")[0] || "/";
  };
  const [route, setRoute] = useState(read);
  useEffect(() => {
    const on = () => {
      const hash = window.location.hash.replace(/^#/, "");
      const anchor = hash && !hash.startsWith("/") ? hash : "";
      setRoute(read());
      if (anchor) {
        window.setTimeout(() => document.getElementById(anchor)?.scrollIntoView({ behavior: "smooth" }), 0);
      } else {
        window.scrollTo({ top: 0, behavior: "instant" as ScrollBehavior });
      }
    };
    window.addEventListener("hashchange", on);
    return () => window.removeEventListener("hashchange", on);
  }, []);
  return route;
}

/* ---------------- Squad state ---------------- */
const KEY = "fpl-sidekick-squad-v2";

function load(): SquadState {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return emptySquad();
    const s = JSON.parse(raw) as SquadState;
    // drop any ids that no longer exist in the data
    Object.keys(s.picks).forEach((k) => {
      if (s.picks[k] && !playersById[s.picks[k] as number]) s.picks[k] = null;
    });
    return s;
  } catch {
    return emptySquad();
  }
}

export function useSquad() {
  const [state, setState] = useState<SquadState>(load);
  const toast = useToast();

  useEffect(() => {
    try {
      localStorage.setItem(KEY, JSON.stringify(state));
    } catch {
      /* storage unavailable */
    }
  }, [state]);

  const setFormation = useCallback(
    (formation: string) => {
      setState((s) => ({ ...s, formation }));
      toast(`Formation changed to ${formation}. Your bench has adjusted.`, "info");
    },
    [toast],
  );

  const assign = useCallback(
    (slotId: string, playerId: number): boolean => {
      const p = playersById[playerId];
      const reason = blockReason(state, p, slotId);
      if (reason) {
        toast(reason, "error");
        return false;
      }
      setState((s) => ({ ...s, picks: { ...s.picks, [slotId]: playerId } }));
      toast(`${p.n} added to your squad.`, "success");
      return true;
    },
    [state, toast],
  );

  const remove = useCallback(
    (slotId: string) => {
      const id = state.picks[slotId];
      setState((s) => ({
        ...s,
        picks: { ...s.picks, [slotId]: null },
        captain: s.captain === id ? null : s.captain,
        vice: s.vice === id ? null : s.vice,
      }));
      if (id) toast(`${playersById[id].n} removed.`, "info");
    },
    [state.picks, toast],
  );

  const setCaptain = useCallback(
    (id: number, kind: "captain" | "vice") => {
      setState((s) => {
        const other = kind === "captain" ? "vice" : "captain";
        return { ...s, [kind]: id, [other]: s[other] === id ? null : s[other] };
      });
      toast(`${playersById[id].n} set as ${kind === "captain" ? "captain" : "vice-captain"}.`, "success");
    },
    [toast],
  );

  const reset = useCallback(() => {
    setState(emptySquad());
    toast("Squad cleared. Fresh start!", "info");
  }, [toast]);

  const auto = useCallback(() => {
    setState(autoPick());
    toast("Sidekick built a balanced squad from the strongest options.", "success");
  }, [toast]);

  const caps = useMemo(() => effectiveCaptains(state), [state]);
  const slots = useMemo(() => allSlots(state.formation), [state.formation]);

  return { state, caps, slots, setFormation, assign, remove, setCaptain, reset, auto };
}

/* ---------------- Live optimal XI ---------------- */
export function useLiveOptimalTeam() {
  const [team, setTeam] = useState<OptimalTeam>(snapshotOptimalTeam);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    setLoading(true);
    try {
      const next = await fetchOptimalTeam();
      setTeam(next);
      setError(null);
    } catch {
      // Keep showing the last valid team if the public feed is briefly unavailable.
      setError("Live FPL data is temporarily unavailable. Showing the latest saved snapshot.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void refresh();
    const timer = window.setInterval(() => void refresh(), 5 * 60 * 1000);
    const onFocus = () => void refresh();
    window.addEventListener("focus", onFocus);
    return () => {
      window.clearInterval(timer);
      window.removeEventListener("focus", onFocus);
    };
  }, [refresh]);

  return { team, loading, error, refresh };
}
