import raw from "../data/fpl.json";

export type Pos = 1 | 2 | 3 | 4;

export interface Player {
  id: number;
  n: string;
  fn: string;
  sn: string;
  t: number;
  p: Pos;
  c: number;
  f: number;
  ppg: number;
  tp: number;
  sel: number;
  st: string;
  news: string;
  ch: number | null;
  ep: number;
  min: number;
  g: number;
  a: number;
  cs: number;
  b: number;
  xgi: number;
  ict: number;
  vs: number;
  ti: number;
  to: number;
  ep0: number;
  cc: number;
}
export interface Team {
  id: number;
  name: string;
  s: string;
}
export interface Fixture {
  e: number;
  o: number;
  h: number;
  d: number;
}

interface Snapshot {
  generated: string;
  totalPlayers: number;
  currentGw: number;
  nextGw: number;
  nextDeadline: string;
  gws: { id: number; avg: number; high: number; top: number; topPts: number; capt: number }[];
  teams: Team[];
  players: Player[];
  fixtures: Record<string, Fixture[]>;
}

export const DATA = raw as unknown as Snapshot;
export const players = DATA.players;
export const teams = DATA.teams;
export const teamsById: Record<number, Team> = Object.fromEntries(teams.map((t) => [t.id, t]));
export const playersById: Record<number, Player> = Object.fromEntries(players.map((p) => [p.id, p]));

export const POS: Record<Pos, { short: string; name: string; plural: string; need: number }> = {
  1: { short: "GKP", name: "Goalkeeper", plural: "Goalkeepers", need: 2 },
  2: { short: "DEF", name: "Defender", plural: "Defenders", need: 5 },
  3: { short: "MID", name: "Midfielder", plural: "Midfielders", need: 5 },
  4: { short: "FWD", name: "Forward", plural: "Forwards", need: 3 },
};

export const BUDGET = 1000;
export const MAX_PER_CLUB = 3;

export const fmtPrice = (c: number) => `£${(c / 10).toFixed(1)}m`;
export const fmtDate = (iso: string, opts?: Intl.DateTimeFormatOptions) =>
  new Date(iso).toLocaleDateString("en-GB", opts ?? { day: "numeric", month: "long", year: "numeric" });

export function fixturesOf(teamId: number, n = 5): Fixture[] {
  return (DATA.fixtures[String(teamId)] ?? []).slice(0, n);
}

/** Average difficulty of the next n fixtures (3.5 when a team has none). */
export function avgFdr(teamId: number, n = 3): number {
  const fx = fixturesOf(teamId, n);
  if (!fx.length) return 3.5;
  return fx.reduce((s, f) => s + f.d, 0) / fx.length;
}

export function availability(p: Player): number {
  if (p.ch !== null && p.ch !== undefined) return p.ch / 100;
  if (p.st === "a") return 1;
  if (p.st === "d") return 0.5;
  return 0;
}

export function statusLabel(p: Player): { text: string; tone: "ok" | "warn" | "bad" } {
  const a = availability(p);
  if (a >= 1) return { text: "Available", tone: "ok" };
  if (a >= 0.5) return { text: `${Math.round(a * 100)}% fit`, tone: "warn" };
  if (a > 0) return { text: `${Math.round(a * 100)}% fit`, tone: "bad" };
  return { text: p.st === "s" ? "Suspended" : p.st === "i" ? "Injured" : "Unavailable", tone: "bad" };
}

/** Sidekick rating: blend of expected points, form and points-per-game, adjusted for fixtures + fitness. */
const ratingCache = new Map<number, number>();
export function rating(p: Player): number {
  const hit = ratingCache.get(p.id);
  if (hit !== undefined) return hit;
  const base = 0.45 * p.ep + 0.35 * p.f + 0.2 * p.ppg;
  const fix = 1 + (3 - avgFdr(p.t, 3)) * 0.07;
  const played = p.min >= 90 ? 1 : 0.3;
  const r = Math.max(0, base) * fix * played * availability(p);
  ratingCache.set(p.id, r);
  return r;
}

/* ---------- percentile helpers (per position, among players who have actually played) ---------- */
function sortedBy(fn: (p: Player) => number) {
  const out: Record<number, number[]> = { 1: [], 2: [], 3: [], 4: [] };
  players.filter((p) => p.min >= 90).forEach((p) => out[p.p].push(fn(p)));
  Object.values(out).forEach((a) => a.sort((x, y) => x - y));
  return out;
}
const formArr = sortedBy((p) => p.f);
const valueArr = sortedBy((p) => p.tp / (p.c / 10));
const epArr = sortedBy((p) => p.ep);

function pct(arr: number[], v: number) {
  if (!arr.length) return 0.5;
  let lo = 0;
  while (lo < arr.length && arr[lo] <= v) lo++;
  return lo / arr.length;
}
export const formPct = (p: Player) => pct(formArr[p.p], p.f);
export const valuePct = (p: Player) => pct(valueArr[p.p], p.tp / (p.c / 10));
export const epPct = (p: Player) => pct(epArr[p.p], p.ep);

export const clamp = (v: number, lo = 0, hi = 1) => Math.min(hi, Math.max(lo, v));

/* ---------- Kit colours ---------- */
export const KITS: Record<string, [string, string]> = {
  ARS: ["#EF0107", "#FFFFFF"],
  AVL: ["#7A003C", "#95BFE5"],
  BOU: ["#DA291C", "#111111"],
  BRE: ["#E30613", "#FFFFFF"],
  BHA: ["#0057B8", "#FFFFFF"],
  CHE: ["#034694", "#FFFFFF"],
  COV: ["#59C3E8", "#FFFFFF"],
  CRY: ["#1B458F", "#C4122E"],
  EVE: ["#003399", "#FFFFFF"],
  FUL: ["#FFFFFF", "#111111"],
  HUL: ["#F5A12D", "#111111"],
  IPS: ["#3A64A3", "#FFFFFF"],
  LEE: ["#F8F8F8", "#1D428A"],
  LIV: ["#C8102E", "#FFFFFF"],
  MCI: ["#6CABDD", "#FFFFFF"],
  MUN: ["#DA291C", "#FBE122"],
  NEW: ["#2B2B2B", "#FFFFFF"],
  NFO: ["#DD0000", "#FFFFFF"],
  TOT: ["#FFFFFF", "#132257"],
  SUN: ["#EB172B", "#FFFFFF"],
};
export const GK_KIT: [string, string] = ["#14B8A6", "#0F172A"];

export const FDR_STYLE: Record<number, string> = {
  1: "bg-emerald-600 text-white",
  2: "bg-emerald-300 text-emerald-950",
  3: "bg-slate-200 text-slate-800",
  4: "bg-rose-300 text-rose-950",
  5: "bg-rose-700 text-white",
};
