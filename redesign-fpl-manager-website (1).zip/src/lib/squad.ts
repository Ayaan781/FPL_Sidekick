import {
  BUDGET,
  MAX_PER_CLUB,
  POS,
  availability,
  avgFdr,
  clamp,
  epPct,
  fmtPrice,
  formPct,
  players,
  playersById,
  rating,
  statusLabel,
  teamsById,
  valuePct,
  type Player,
  type Pos,
} from "./data";

export const FORMATIONS = ["3-4-3", "3-5-2", "4-3-3", "4-4-2", "4-5-1", "5-2-3", "5-3-2", "5-4-1"];

export interface Slot {
  id: string;
  pos: Pos;
  bench: boolean;
}
export interface SquadState {
  formation: string;
  picks: Record<string, number | null>;
  captain: number | null;
  vice: number | null;
}

export const emptySquad = (): SquadState => ({ formation: "4-4-2", picks: {}, captain: null, vice: null });

export function buildSlots(formation: string): { xi: Slot[]; bench: Slot[] } {
  const [d, m, f] = formation.split("-").map(Number);
  const counts: Record<Pos, number> = { 1: 1, 2: d, 3: m, 4: f };
  const xi: Slot[] = [];
  const bench: Slot[] = [];
  ([1, 2, 3, 4] as Pos[]).forEach((pos) => {
    for (let i = 0; i < POS[pos].need; i++) {
      const slot = { id: `${POS[pos].short}-${i}`, pos, bench: i >= counts[pos] };
      (slot.bench ? bench : xi).push(slot);
    }
  });
  // bench order: keeper first, then outfield players
  bench.sort((a, b) => (a.pos === 1 ? -1 : b.pos === 1 ? 1 : a.pos - b.pos));
  return { xi, bench };
}

export const allSlots = (formation: string) => {
  const { xi, bench } = buildSlots(formation);
  return [...xi, ...bench];
};

export function squadPlayers(s: SquadState): Player[] {
  return allSlots(s.formation)
    .map((sl) => s.picks[sl.id])
    .filter((id): id is number => typeof id === "number")
    .map((id) => playersById[id])
    .filter(Boolean);
}
export const spent = (s: SquadState) => squadPlayers(s).reduce((t, p) => t + p.c, 0);

export function clubCounts(list: Player[]) {
  const m: Record<number, number> = {};
  list.forEach((p) => (m[p.t] = (m[p.t] ?? 0) + 1));
  return m;
}

/** Returns a reason why `player` can't go in `slotId`, or null if it's fine. */
export function blockReason(s: SquadState, player: Player, slotId: string): string | null {
  const current = s.picks[slotId];
  const others = squadPlayers(s).filter((p) => p.id !== current);
  if (others.some((p) => p.id === player.id)) return "Already in your squad";
  const cost = others.reduce((t, p) => t + p.c, 0) + player.c;
  if (cost > BUDGET) return `Over budget by ${fmtPrice(cost - BUDGET)}`;
  if (others.filter((p) => p.t === player.t).length >= MAX_PER_CLUB)
    return `Max ${MAX_PER_CLUB} players from ${teamsById[player.t].name}`;
  return null;
}

export function effectiveCaptains(s: SquadState) {
  const xiIds = buildSlots(s.formation)
    .xi.map((sl) => s.picks[sl.id])
    .filter((x): x is number => typeof x === "number");
  const captain = s.captain && xiIds.includes(s.captain) ? s.captain : null;
  const vice = s.vice && xiIds.includes(s.vice) && s.vice !== captain ? s.vice : null;
  return { captain, vice };
}

/* ====================================================================== */
/*  Review / scoring                                                       */
/* ====================================================================== */

export type Tone = "good" | "warn" | "bad";
export interface Note {
  tone: Tone;
  text: string;
}
export interface Category {
  key: string;
  label: string;
  score: number;
  max: number;
  verdict: string;
  tip: string;
}
export interface PlayerReview {
  player: Player;
  slot: Slot;
  notes: Note[];
  swap?: { to: Player; gain: number };
}
export interface Review {
  score: number;
  grade: string;
  headline: string;
  categories: Category[];
  players: PlayerReview[];
  captainPick: Player | null;
  topMoves: { from: Player; to: Player; gain: number }[];
  spent: number;
}

const avg = (a: number[]) => (a.length ? a.reduce((x, y) => x + y, 0) / a.length : 0);

export function isComplete(s: SquadState) {
  return squadPlayers(s).length === 15;
}

function bestSwap(s: SquadState, p: Player, slotId: string): { to: Player; gain: number } | undefined {
  const base = rating(p);
  let best: { to: Player; gain: number } | undefined;
  for (const c of players) {
    if (c.p !== p.p || c.id === p.id) continue;
    const r = rating(c);
    if (r < base * 1.2 || r - base < 0.6) continue;
    if (blockReason(s, c, slotId)) continue;
    const gain = r - base;
    if (!best || gain > best.gain) best = { to: c, gain };
  }
  return best;
}

export function buildReview(s: SquadState): Review {
  const { xi, bench } = buildSlots(s.formation);
  const get = (sl: Slot) => playersById[s.picks[sl.id] as number];
  const xiP = xi.map(get);
  const benchP = bench.map(get);
  const all = [...xiP, ...benchP];
  const total = spent(s);
  const { captain } = effectiveCaptains(s);

  /* 1 — Form (25) */
  const formAvg = avg(xiP.map(formPct));
  const formScore = clamp((formAvg - 0.2) / 0.6) * 25;

  /* 2 — Fixtures (20) */
  const fdr = avg(xiP.map((p) => avgFdr(p.t, 3)));
  const fixScore = clamp((3.9 - fdr) / 1.5) * 20;

  /* 3 — Availability (20) */
  const availXi = avg(xiP.map(availability));
  const availBench = avg(benchP.map(availability));
  const availScore = (availXi * 0.88 + availBench * 0.12) * 20;

  /* 4 — Value & budget (15) */
  const valAvg = avg(xiP.map(valuePct));
  const spare = BUDGET - total;
  const spareFactor = clamp(1 - Math.max(0, spare - 20) / 80);
  const valueScore = clamp((valAvg - 0.2) / 0.6) * 10 + spareFactor * 5;

  /* 5 — Structure (20): captain 8 · bench 6 · club spread 6 */
  const epRanked = [...xiP].sort((a, b) => b.ep - a.ep);
  const capRank = captain ? epRanked.findIndex((p) => p.id === captain) : -1;
  const capScore = captain ? clamp(1 - capRank / 6) * 8 : 0;
  const benchScore = avg(benchP.map((p) => availability(p) * (0.4 + 0.6 * formPct(p)))) * 6;
  const clubs = Object.keys(clubCounts(all)).length;
  const spreadScore = clamp((clubs - 5) / 5) * 6;
  const structScore = capScore + benchScore + spreadScore;

  const verdict = (ratio: number, good: string, ok: string, weak: string) =>
    ratio >= 0.75 ? good : ratio >= 0.45 ? ok : weak;

  const bestCap = epRanked[0];
  const categories: Category[] = [
    {
      key: "form",
      label: "Current form",
      score: formScore,
      max: 25,
      verdict: verdict(
        formScore / 25,
        "Your starters are in strong form compared with others in their position.",
        "Mixed form — a few starters are lagging behind the pack.",
        "Most of your starting XI are out of form right now.",
      ),
      tip: `Average form percentile ${(formAvg * 100).toFixed(0)}% across your XI.`,
    },
    {
      key: "fixtures",
      label: "Fixture run",
      score: fixScore,
      max: 20,
      verdict: verdict(
        fixScore / 20,
        "A friendly run of fixtures is coming up for your starters.",
        "An average fixture run — nothing alarming, nothing special.",
        "Your starters face a tough set of opponents in the next few rounds.",
      ),
      tip: `Average difficulty over the next 3 fixtures: ${fdr.toFixed(2)} (lower is better).`,
    },
    {
      key: "avail",
      label: "Availability",
      score: availScore,
      max: 20,
      verdict: verdict(
        availScore / 20,
        "Everyone looks fit and ready for the deadline.",
        "A few injury or suspension flags to keep an eye on.",
        "Several players are doubtful or ruled out — fix these first.",
      ),
      tip: `${xiP.filter((p) => availability(p) < 1).length} of your starting XI carry a flag.`,
    },
    {
      key: "value",
      label: "Value & budget",
      score: valueScore,
      max: 15,
      verdict: verdict(
        valueScore / 15,
        "Excellent points-per-million and a well-spent budget.",
        "Reasonable value, though some funds could work harder.",
        "Weak returns for the money, or too much budget left unused.",
      ),
      tip: `${fmtPrice(total)} spent · ${fmtPrice(Math.max(0, spare))} in the bank.`,
    },
    {
      key: "structure",
      label: "Captain, bench & spread",
      score: structScore,
      max: 20,
      verdict: verdict(
        structScore / 20,
        "Smart captaincy, a playable bench and a healthy spread of clubs.",
        "Decent structure — check your captain and bench cover.",
        "Captaincy, bench depth or club spread need attention.",
      ),
      tip: captain
        ? `Captain ${playersById[captain].n} ranks #${capRank + 1} in your XI for expected points${
            bestCap && bestCap.id !== captain ? ` — ${bestCap.n} is projected higher` : ""
          }.`
        : "No captain chosen — pick one to earn the full captaincy marks.",
    },
  ];

  const score = Math.round(categories.reduce((t, c) => t + c.score, 0));
  const grade = score >= 85 ? "Elite" : score >= 72 ? "Strong" : score >= 58 ? "Solid" : score >= 45 ? "Needs work" : "Rebuild";
  const headline =
    score >= 85
      ? "Outstanding squad — you're well set for the deadline."
      : score >= 72
        ? "A strong squad with just a few tweaks left to make."
        : score >= 58
          ? "A solid base. A couple of smart moves could lift it quickly."
          : score >= 45
            ? "Some real weak spots here — start with the flagged players below."
            : "This squad needs a rethink. Use the suggested swaps to get going.";

  /* Per-player notes */
  const reviews: PlayerReview[] = [...xi, ...bench].map((slot) => {
    const p = get(slot);
    const notes: Note[] = [];
    const st = statusLabel(p);
    if (st.tone === "bad") notes.push({ tone: "bad", text: p.news || `${st.text} for the next round.` });
    else if (st.tone === "warn") notes.push({ tone: "warn", text: p.news || "Fitness doubt for the next round." });
    if (p.min < 180 && !slot.bench) notes.push({ tone: "warn", text: `Only ${p.min} minutes played — rotation risk.` });
    const f3 = avgFdr(p.t, 3);
    if (f3 >= 3.8) notes.push({ tone: "warn", text: `Tough run ahead (avg difficulty ${f3.toFixed(1)}).` });
    else if (f3 <= 2.4) notes.push({ tone: "good", text: `Favourable run ahead (avg difficulty ${f3.toFixed(1)}).` });
    const fp = formPct(p);
    if (p.min >= 90 && fp >= 0.8) notes.push({ tone: "good", text: `Form of ${p.f.toFixed(1)} is in the top 20% of ${POS[p.p].plural.toLowerCase()}.` });
    else if (p.min >= 90 && fp <= 0.25 && !slot.bench)
      notes.push({ tone: "warn", text: `Form of ${p.f.toFixed(1)} is below most ${POS[p.p].plural.toLowerCase()}.` });
    if (p.min >= 180 && valuePct(p) >= 0.85) notes.push({ tone: "good", text: `Great value at ${fmtPrice(p.c)}.` });
    if (epPct(p) >= 0.9 && p.min >= 90) notes.push({ tone: "good", text: `Projected ${p.ep.toFixed(1)} pts next round.` });
    if (!notes.length) notes.push({ tone: "good", text: "No concerns — a reliable pick." });
    const swap = notes.some((n) => n.tone !== "good") ? bestSwap(s, p, slot.id) : undefined;
    return { player: p, slot, notes, swap };
  });

  const topMoves = reviews
    .filter((r) => r.swap)
    .sort((a, b) => b.swap!.gain - a.swap!.gain)
    .slice(0, 3)
    .map((r) => ({ from: r.player, to: r.swap!.to, gain: r.swap!.gain }));

  return { score, grade, headline, categories, players: reviews, captainPick: bestCap ?? null, topMoves, spent: total };
}

export function reportText(s: SquadState, r: Review, manager?: string): string {
  const { captain, vice } = effectiveCaptains(s);
  const lines: string[] = [];
  lines.push("FPL SIDEKICK — SQUAD REVIEW");
  if (manager) lines.push(`Manager: ${manager}`);
  lines.push(`Formation: ${s.formation}   Spend: ${fmtPrice(r.spent)}`);
  lines.push(`Score: ${r.score}/100 (${r.grade})`);
  lines.push(r.headline, "");
  lines.push("CATEGORY BREAKDOWN");
  r.categories.forEach((c) => lines.push(`- ${c.label}: ${c.score.toFixed(1)}/${c.max} — ${c.verdict}`));
  lines.push("", "SQUAD");
  r.players.forEach((pr) => {
    const tag = pr.player.id === captain ? " (C)" : pr.player.id === vice ? " (VC)" : "";
    lines.push(
      `${pr.slot.bench ? "BENCH" : "XI   "} ${POS[pr.player.p].short} ${pr.player.n}${tag} · ${teamsById[pr.player.t].s} · ${fmtPrice(pr.player.c)}`,
    );
    pr.notes.forEach((n) => lines.push(`      ${n.tone === "good" ? "+" : n.tone === "warn" ? "!" : "x"} ${n.text}`));
    if (pr.swap) lines.push(`      -> Consider ${pr.swap.to.n} (${teamsById[pr.swap.to.t].s}, ${fmtPrice(pr.swap.to.c)})`);
  });
  lines.push("", "Based on an official FPL data snapshot. Estimates are not guaranteed points.");
  return lines.join("\n");
}

/* ====================================================================== */
/*  Auto-pick                                                              */
/* ====================================================================== */

const WEIGHTS: Record<Pos, number[]> = {
  1: [1, 0.08],
  2: [1, 1, 1, 1, 0.08],
  3: [1, 1, 1, 1, 0.08],
  4: [1, 1, 0.08],
};

function objective(squad: Player[]) {
  let t = 0;
  ([1, 2, 3, 4] as Pos[]).forEach((pos) => {
    squad
      .filter((p) => p.p === pos)
      .map(rating)
      .sort((a, b) => b - a)
      .forEach((r, i) => (t += r * (WEIGHTS[pos][i] ?? 0)));
  });
  return t;
}

export function autoPick(): SquadState {
  const eligible = players.filter((p) => p.min >= 90 && availability(p) >= 1);
  const squad: Player[] = [];
  const valid = (list: Player[], cand: Player) =>
    list.filter((p) => p.t === cand.t).length < MAX_PER_CLUB && !list.some((p) => p.id === cand.id);

  // 1. cheapest playable fill
  ([1, 2, 3, 4] as Pos[]).forEach((pos) => {
    const pool = eligible.filter((p) => p.p === pos).sort((a, b) => a.c - b.c || rating(b) - rating(a));
    for (const c of pool) {
      if (squad.filter((p) => p.p === pos).length >= POS[pos].need) break;
      if (valid(squad, c)) squad.push(c);
    }
  });

  // 2. greedy upgrades by gain per extra £
  for (let guard = 0; guard < 80; guard++) {
    const cost = squad.reduce((t, p) => t + p.c, 0);
    const base = objective(squad);
    let best: { i: number; c: Player; score: number } | null = null;
    squad.forEach((cur, i) => {
      const rest = squad.filter((_, j) => j !== i);
      for (const c of eligible) {
        if (c.p !== cur.p || !valid(rest, c)) continue;
        const dc = c.c - cur.c;
        if (cost + dc > BUDGET) continue;
        const gain = objective([...rest, c]) - base;
        if (gain <= 0.001) continue;
        const sc = gain / (Math.max(dc, 0) + 4);
        if (!best || sc > best.score) best = { i, c, score: sc };
      }
    });
    if (!best) break;
    const b = best as { i: number; c: Player; score: number };
    squad[b.i] = b.c;
  }

  // 3. pick best formation
  let bestForm = "4-4-2";
  let bestVal = -1;
  FORMATIONS.forEach((f) => {
    const [d, m, fw] = f.split("-").map(Number);
    const need: Record<Pos, number> = { 1: 1, 2: d, 3: m, 4: fw };
    let v = 0;
    ([1, 2, 3, 4] as Pos[]).forEach((pos) => {
      squad
        .filter((p) => p.p === pos)
        .sort((a, b) => rating(b) - rating(a))
        .slice(0, need[pos])
        .forEach((p) => (v += rating(p)));
    });
    if (v > bestVal) {
      bestVal = v;
      bestForm = f;
    }
  });

  const picks: Record<string, number | null> = {};
  const { xi, bench } = buildSlots(bestForm);
  ([1, 2, 3, 4] as Pos[]).forEach((pos) => {
    const sorted = squad.filter((p) => p.p === pos).sort((a, b) => rating(b) - rating(a));
    const slots = [...xi, ...bench].filter((sl) => sl.pos === pos).sort((a, b) => Number(a.bench) - Number(b.bench));
    slots.forEach((sl, i) => (picks[sl.id] = sorted[i]?.id ?? null));
  });
  const xiPlayers = xi.map((sl) => playersById[picks[sl.id] as number]).sort((a, b) => b.ep - a.ep);
  return { formation: bestForm, picks, captain: xiPlayers[0]?.id ?? null, vice: xiPlayers[1]?.id ?? null };
}
