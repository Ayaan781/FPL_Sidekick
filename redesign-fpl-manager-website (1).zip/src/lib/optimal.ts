import {
  BUDGET,
  DATA,
  MAX_PER_CLUB,
  POS,
  availability,
  players,
  teamsById,
  type Fixture,
  type Player,
  type Pos,
} from "./data";

const BOOTSTRAP_URL = "https://fantasy.premierleague.com/api/bootstrap-static/";
const FIXTURES_URL = "https://fantasy.premierleague.com/api/fixtures/";
const LIVE_MIRROR_URL = "https://raw.githubusercontent.com/ayaan781/Fantasy-Premier-League-Manager/main/public/fpl-live.json";
const FORMATIONS = ["3-4-3", "3-5-2", "4-3-3", "4-4-2", "4-5-1", "5-2-3", "5-3-2", "5-4-1"];

interface RawEvent {
  id: number;
  deadline_time: string;
  finished: boolean;
  is_current: boolean;
  is_next: boolean;
}

interface RawTeam {
  id: number;
  name: string;
  short_name: string;
}

interface RawPlayer {
  id: number;
  web_name: string;
  first_name: string;
  second_name: string;
  team: number;
  element_type: Pos;
  now_cost: number;
  form: string;
  points_per_game: string;
  total_points: number;
  selected_by_percent: string;
  status: string;
  news: string;
  chance_of_playing_next_round: number | null;
  ep_next: string;
  minutes: number;
  goals_scored: number;
  assists: number;
  clean_sheets: number;
  bonus: number;
  expected_goal_involvements: string;
  ict_index: string;
  transfers_in_event: number;
  transfers_out_event: number;
  event_points: number;
  cost_change_start: number;
}

interface RawBootstrap {
  events: RawEvent[];
  teams: RawTeam[];
  elements: RawPlayer[];
}

interface RawFixture {
  event: number | null;
  finished: boolean;
  team_a: number;
  team_h: number;
  team_h_difficulty: number;
  team_a_difficulty: number;
}

interface LiveMirror {
  generatedAt: string;
  gameweek: number;
  deadline: string;
  teamNames: Record<number, { name: string; short: string }>;
  players: Player[];
  fixtures: Record<string, Fixture[]>;
}

interface LiveData {
  players: Player[];
  fixtures: Record<string, Fixture[]>;
  gameweek: number;
  deadline: string;
  updatedAt: string;
  teamNames: Record<number, { name: string; short: string }>;
}

export interface OptimalPlayer extends Player {
  projected: number;
}

export interface OptimalTeam {
  source: "live" | "snapshot";
  updatedAt: string;
  gameweek: number;
  deadline: string;
  formation: string;
  squad: OptimalPlayer[];
  xi: OptimalPlayer[];
  bench: OptimalPlayer[];
  captain: OptimalPlayer;
  vice: OptimalPlayer;
  projected: number;
  spend: number;
  fixtures: Record<string, Fixture[]>;
  teamNames: Record<number, { name: string; short: string }>;
}

const n = (value: string | number | null | undefined) => (value == null || value === "" ? 0 : Number(value));

function toPlayer(p: RawPlayer): Player {
  return {
    id: p.id,
    n: p.web_name,
    fn: p.first_name,
    sn: p.second_name,
    t: p.team,
    p: p.element_type,
    c: p.now_cost,
    f: n(p.form),
    ppg: n(p.points_per_game),
    tp: p.total_points,
    sel: n(p.selected_by_percent),
    st: p.status,
    news: p.news || "",
    ch: p.chance_of_playing_next_round,
    ep: n(p.ep_next),
    min: p.minutes,
    g: p.goals_scored,
    a: p.assists,
    cs: p.clean_sheets,
    b: p.bonus,
    xgi: n(p.expected_goal_involvements),
    ict: n(p.ict_index),
    vs: p.now_cost ? p.total_points / (p.now_cost / 10) : 0,
    ti: p.transfers_in_event,
    to: p.transfers_out_event,
    ep0: p.event_points,
    cc: p.cost_change_start,
  };
}

function nextEvent(events: RawEvent[]) {
  return events.find((event) => event.is_next) || events.find((event) => !event.finished) || events[events.length - 1];
}

function normalizeFixtures(raw: RawFixture[]): Record<string, Fixture[]> {
  const output: Record<string, Fixture[]> = {};
  raw
    .filter((fixture) => !fixture.finished && fixture.event !== null)
    .sort((a, b) => (a.event ?? 99) - (b.event ?? 99))
    .forEach((fixture) => {
      const home: Fixture = { e: fixture.event!, o: fixture.team_a, h: 1, d: fixture.team_h_difficulty };
      const away: Fixture = { e: fixture.event!, o: fixture.team_h, h: 0, d: fixture.team_a_difficulty };
      (output[fixture.team_h] ||= []).push(home);
      (output[fixture.team_a] ||= []).push(away);
    });
  return output;
}

function normalizeLive(bootstrap: RawBootstrap, rawFixtures: RawFixture[]): LiveData {
  const event = nextEvent(bootstrap.events);
  if (!event) throw new Error("No upcoming gameweek is available.");
  return {
    players: bootstrap.elements.filter((p) => p.status !== "u" && !((p as RawPlayer & { removed?: boolean }).removed)).map(toPlayer),
    fixtures: normalizeFixtures(rawFixtures),
    gameweek: event.id,
    deadline: event.deadline_time,
    updatedAt: new Date().toISOString(),
    teamNames: Object.fromEntries(bootstrap.teams.map((team) => [team.id, { name: team.name, short: team.short_name }])),
  };
}

function fixturesFor(fixtures: Record<string, Fixture[]>, teamId: number, gameweek: number) {
  return (fixtures[String(teamId)] || []).filter((fixture) => fixture.e === gameweek);
}

function projected(player: Player, fixtures: Record<string, Fixture[]>, gameweek: number): number {
  const upcoming = fixturesFor(fixtures, player.t, gameweek);
  const hasAnyUpcoming = Object.values(fixtures).some((items) => items.some((fixture) => fixture.e >= gameweek));
  // At the end of a season there may be no future fixture rows at all. Keep
  // the module useful in that edge case instead of returning an empty XI.
  if (!upcoming.length) return hasAnyUpcoming ? 0 : Math.max(player.ep, player.ppg, player.f, 2) * availability(player);
  const base = player.ep || player.ppg || player.f || 2;
  const difficulty = upcoming.reduce((total, fixture) => total + fixture.d, 0) / upcoming.length;
  const doubleGameweek = upcoming.length > 1 ? 1.12 : 1;
  const fixtureBoost = 1 + (3 - difficulty) * 0.05;
  const fitness = availability(player);
  const minutesRisk = player.min > 0 ? 1 : 0.72;
  return Math.max(0, base * doubleGameweek * fixtureBoost * fitness * minutesRisk);
}

function formationCounts(formation: string): Record<Pos, number> {
  const [def, mid, fwd] = formation.split("-").map(Number);
  return { 1: 1, 2: def as number, 3: mid as number, 4: fwd as number };
}

function bestLineup(squad: OptimalPlayer[]) {
  let best = { formation: "4-4-2", xi: [] as OptimalPlayer[], points: -1 };
  FORMATIONS.forEach((formation) => {
    const counts = formationCounts(formation);
    const xi = ([1, 2, 3, 4] as Pos[]).flatMap((pos) =>
      squad
        .filter((player) => player.p === pos)
        .sort((a, b) => b.projected - a.projected)
        .slice(0, counts[pos]),
    );
    const points = xi.reduce((total, player) => total + player.projected, 0);
    if (xi.length === 11 && points > best.points) best = { formation, xi, points };
  });
  return best;
}

function objective(squad: OptimalPlayer[]) {
  const lineup = bestLineup(squad);
  return lineup.points;
}

function canUse(rest: OptimalPlayer[], player: OptimalPlayer) {
  return !rest.some((item) => item.id === player.id) && rest.filter((item) => item.t === player.t).length < MAX_PER_CLUB;
}

function chooseSquad(source: Player[], fixtures: Record<string, Fixture[]>, gameweek: number) {
  const enriched = source.map((player) => ({ ...player, projected: projected(player, fixtures, gameweek) }));
  const available = enriched.filter((player) => player.projected > 0 && availability(player) >= 0.75);
  const pool = ([1, 2, 3, 4] as Pos[]).map((pos) => {
    const strict = available.filter((player) => player.p === pos);
    return strict.length >= POS[pos].need ? strict : enriched.filter((player) => player.p === pos && player.projected > 0);
  });
  const squad: OptimalPlayer[] = [];

  // Start with the cheapest legal 15, then spend the remaining budget on upgrades.
  ([1, 2, 3, 4] as Pos[]).forEach((pos, index) => {
    const candidates = pool[index].slice().sort((a, b) => a.c - b.c || b.projected - a.projected);
    for (const candidate of candidates) {
      if (squad.filter((player) => player.p === pos).length >= POS[pos].need) break;
      if (canUse(squad, candidate)) squad.push(candidate);
    }
  });

  for (let pass = 0; pass < 100; pass += 1) {
    const currentCost = squad.reduce((total, player) => total + player.c, 0);
    const currentScore = objective(squad);
    let best: { index: number; player: OptimalPlayer; rank: number } | undefined;
    squad.forEach((current, index) => {
      const rest = squad.filter((_, itemIndex) => itemIndex !== index);
      enriched
        .filter((candidate) => candidate.p === current.p && candidate.projected > 0 && canUse(rest, candidate))
        .forEach((candidate) => {
          if (currentCost - current.c + candidate.c > BUDGET) return;
          const gain = objective([...rest, candidate]) - currentScore;
          if (gain <= 0.01) return;
          const priceChange = Math.max(0, candidate.c - current.c);
          const rank = gain / (priceChange + 5);
          if (!best || rank > best.rank) best = { index, player: candidate, rank };
        });
    });
    if (!best) break;
    squad[best.index] = best.player;
  }
  return squad;
}

export function createOptimalTeam(data: LiveData, source: "live" | "snapshot"): OptimalTeam {
  const squad = chooseSquad(data.players, data.fixtures, data.gameweek);
  const lineup = bestLineup(squad);
  if (squad.length < 15 || lineup.xi.length < 11) throw new Error("There are not enough eligible players to build an optimal team.");
  const bench = squad
    .filter((player) => !lineup.xi.some((starter) => starter.id === player.id))
    .sort((a, b) => (a.p === 1 ? -1 : b.p === 1 ? 1 : a.p - b.p));
  const captain = lineup.xi.slice().sort((a, b) => b.projected - a.projected)[0] || squad[0];
  const vice = lineup.xi.slice().sort((a, b) => b.projected - a.projected)[1] || captain;
  const spend = squad.reduce((total, player) => total + player.c, 0);
  const budgetBonus = captain ? captain.projected : 0;
  return {
    source,
    updatedAt: data.updatedAt,
    gameweek: data.gameweek,
    deadline: data.deadline,
    formation: lineup.formation,
    squad,
    xi: lineup.xi,
    bench,
    captain,
    vice,
    projected: lineup.points + budgetBonus,
    spend,
    fixtures: data.fixtures,
    teamNames: data.teamNames,
  };
}

const snapshotData: LiveData = {
  players,
  fixtures: DATA.fixtures,
  gameweek: DATA.nextGw,
  deadline: DATA.nextDeadline,
  updatedAt: DATA.generated,
  teamNames: Object.fromEntries(Object.values(teamsById).map((team) => [team.id, { name: team.name, short: team.s }])),
};

export const snapshotOptimalTeam = createOptimalTeam(snapshotData, "snapshot");

export async function fetchOptimalTeam(): Promise<OptimalTeam> {
  // GitHub Pages cannot read the official feed directly because it does not
  // expose browser CORS headers. The scheduled mirror is the primary source.
  const localMirror = typeof window === "undefined" ? "/fpl-live.json" : new URL("fpl-live.json", window.location.href).href;
  const mirrorUrls = [localMirror, `${LIVE_MIRROR_URL}?v=${Math.floor(Date.now() / 300000)}`];
  for (const url of mirrorUrls) {
    try {
      const mirrorResponse = await fetch(`${url}${url.includes("?") ? "&" : "?"}t=${Date.now()}`, { cache: "no-store" });
      if (mirrorResponse.ok) {
        const mirror = (await mirrorResponse.json()) as LiveMirror;
        return createOptimalTeam(
          {
            players: mirror.players,
            fixtures: mirror.fixtures,
            gameweek: mirror.gameweek,
            deadline: mirror.deadline,
            updatedAt: mirror.generatedAt,
            teamNames: mirror.teamNames,
          },
          "live",
        );
      }
    } catch {
      // Try the next mirror or the official feed below.
    }
  }

  const [bootstrapResponse, fixturesResponse] = await Promise.all([
    fetch(BOOTSTRAP_URL, { headers: { Accept: "application/json" }, cache: "no-store" }),
    fetch(FIXTURES_URL, { headers: { Accept: "application/json" }, cache: "no-store" }),
  ]);
  if (!bootstrapResponse.ok || !fixturesResponse.ok) throw new Error("The official FPL feed is unavailable right now.");
  const bootstrap = (await bootstrapResponse.json()) as RawBootstrap;
  const rawFixtures = (await fixturesResponse.json()) as RawFixture[];
  return createOptimalTeam(normalizeLive(bootstrap, rawFixtures), "live");
}
