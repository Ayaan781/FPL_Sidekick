import { useEffect } from "react";
import { Footer, Nav } from "./components/ui";
import { ToastProvider, useRoute } from "./lib/hooks";
import Home from "./pages/Home";
import Builder from "./pages/Builder";
import Insights from "./pages/Insights";
import Fixtures from "./pages/Fixtures";
import Guide from "./pages/Guide";

const TITLES: Record<string, string> = {
  "/": "FPL Sidekick — Fantasy Premier League Squad Builder & Review",
  "/builder": "Build your squad — FPL Sidekick",
  "/insights": "Player insights — FPL Sidekick",
  "/fixtures": "Fixture difficulty ticker — FPL Sidekick",
  "/guide": "FPL guide — FPL Sidekick",
};

function Shell() {
  const route = useRoute();
  useEffect(() => {
    document.title = TITLES[route] ?? TITLES["/"];
  }, [route]);

  const Page = { "/builder": Builder, "/insights": Insights, "/fixtures": Fixtures, "/guide": Guide }[route] ?? Home;

  return (
    <div className="flex min-h-screen flex-col">
      <a href="#main" onClick={(e) => { e.preventDefault(); document.getElementById("main")?.focus(); }} className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[200] focus:rounded-lg focus:bg-emerald-500 focus:px-4 focus:py-2 focus:font-semibold focus:text-ink-950">
        Skip to content
      </a>
      <Nav route={route in TITLES ? route : "/"} />
      <main id="main" tabIndex={-1} className="flex-1 outline-none">
        <Page />
      </main>
      <Footer />
    </div>
  );
}

export default function App() {
  return (
    <ToastProvider>
      <Shell />
    </ToastProvider>
  );
}
