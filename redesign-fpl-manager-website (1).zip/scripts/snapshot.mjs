import fs from "fs";
const d = JSON.parse(fs.readFileSync("/tmp/fpl.json"));
const f = JSON.parse(fs.readFileSync("/tmp/fix.json"));
const num = (v) => (v == null ? 0 : Number(v));
const players = d.elements
  .filter((e) => e.status !== "u")
  .map((e) => ({
    id: e.id,
    n: e.web_name,
    fn: e.first_name,
    sn: e.second_name,
    t: e.team,
    p: e.element_type,
    c: e.now_cost,
    f: num(e.form),
    ppg: num(e.points_per_game),
    tp: e.total_points,
    sel: num(e.selected_by_percent),
    st: e.status,
    news: e.news || "",
    ch: e.chance_of_playing_next_round,
    ep: num(e.ep_next),
    min: e.minutes,
    g: e.goals_scored,
    a: e.assists,
    cs: e.clean_sheets,
    b: e.bonus,
    xgi: num(e.expected_goal_involvements),
    ict: num(e.ict_index),
    vs: num(e.value_season),
    ti: e.transfers_in_event,
    to: e.transfers_out_event,
    ep0: e.event_points,
    cc: e.cost_change_start,
  }));
const teams = d.teams.map((t) => ({ id: t.id, name: t.name, s: t.short_name }));
const nextEv = d.events.find((e) => e.is_next) || d.events.find((e) => !e.finished);
const fixtures = {};
teams.forEach((t) => (fixtures[t.id] = []));
f.filter((x) => !x.finished && x.event).sort((a, b) => a.event - b.event || new Date(a.kickoff_time) - new Date(b.kickoff_time))
  .forEach((x) => {
    fixtures[x.team_h].push({ e: x.event, o: x.team_a, h: 1, d: x.team_h_difficulty });
    fixtures[x.team_a].push({ e: x.event, o: x.team_h, h: 0, d: x.team_a_difficulty });
  });
Object.keys(fixtures).forEach((k) => (fixtures[k] = fixtures[k].slice(0, 12)));
const finished = d.events.filter((e) => e.finished);
const gws = finished.map((e) => ({ id: e.id, avg: e.average_entry_score, high: e.highest_score, top: e.top_element, topPts: e.top_element_info?.points, capt: e.most_captained }));
const out = {
  generated: new Date().toISOString(),
  totalPlayers: d.total_players,
  currentGw: (d.events.find((e) => e.is_current) || {}).id,
  nextGw: nextEv.id,
  nextDeadline: nextEv.deadline_time,
  gws,
  teams,
  players,
  fixtures,
};
fs.writeFileSync("src/data/fpl.json", JSON.stringify(out));
console.log(players.length, JSON.stringify(out).length);
