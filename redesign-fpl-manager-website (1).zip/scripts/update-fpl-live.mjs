import fs from "node:fs";

const base = "https://fantasy.premierleague.com/api";
const [bootstrapResponse, fixturesResponse] = await Promise.all([
  fetch(`${base}/bootstrap-static/`),
  fetch(`${base}/fixtures/`),
]);

if (!bootstrapResponse.ok || !fixturesResponse.ok) {
  throw new Error(`FPL API request failed: ${bootstrapResponse.status}/${fixturesResponse.status}`);
}

const [bootstrap, fixtures] = await Promise.all([bootstrapResponse.json(), fixturesResponse.json()]);
const event = bootstrap.events.find((item) => item.is_next) || bootstrap.events.find((item) => !item.finished) || bootstrap.events.at(-1);
if (!event) throw new Error("No upcoming FPL gameweek found");

const number = (value) => (value == null || value === "" ? 0 : Number(value));
const teamNames = Object.fromEntries(bootstrap.teams.map((team) => [team.id, { name: team.name, short: team.short_name }]));
const fixtureMap = {};
fixtures
  .filter((fixture) => !fixture.finished && fixture.event !== null)
  .sort((a, b) => a.event - b.event)
  .forEach((fixture) => {
    (fixtureMap[fixture.team_h] ||= []).push({ e: fixture.event, o: fixture.team_a, h: 1, d: fixture.team_h_difficulty });
    (fixtureMap[fixture.team_a] ||= []).push({ e: fixture.event, o: fixture.team_h, h: 0, d: fixture.team_a_difficulty });
  });

const players = bootstrap.elements
  .filter((player) => player.status !== "u" && !player.removed)
  .map((player) => ({
    id: player.id,
    n: player.web_name,
    fn: player.first_name,
    sn: player.second_name,
    t: player.team,
    p: player.element_type,
    c: player.now_cost,
    f: number(player.form),
    ppg: number(player.points_per_game),
    tp: player.total_points,
    sel: number(player.selected_by_percent),
    st: player.status,
    news: player.news || "",
    ch: player.chance_of_playing_next_round,
    ep: number(player.ep_next),
    min: player.minutes,
    g: player.goals_scored,
    a: player.assists,
    cs: player.clean_sheets,
    b: player.bonus,
    xgi: number(player.expected_goal_involvements),
    ict: number(player.ict_index),
    vs: player.now_cost ? player.total_points / (player.now_cost / 10) : 0,
    ti: player.transfers_in_event,
    to: player.transfers_out_event,
    ep0: player.event_points,
    cc: player.cost_change_start,
  }));

fs.mkdirSync("public", { recursive: true });
fs.writeFileSync(
  "public/fpl-live.json",
  JSON.stringify({ generatedAt: new Date().toISOString(), gameweek: event.id, deadline: event.deadline_time, teamNames, players, fixtures: fixtureMap }),
);
console.log(`Saved live FPL data: ${players.length} players, ${fixtures.length} fixtures`);